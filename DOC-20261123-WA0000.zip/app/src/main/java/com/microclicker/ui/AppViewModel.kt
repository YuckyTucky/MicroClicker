package com.microclicker.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.microclicker.core.Graph
import com.microclicker.core.Ids
import com.microclicker.core.Macro
import com.microclicker.core.Step

sealed interface Screen {
    data object Home : Screen
    data object MacroEditor : Screen
    data class StepEditor(val stepId: String) : Screen
    data object Photos : Screen
    data object JsonEditor : Screen
}

/**
 * Holds the navigation stack and the macro currently being edited ("draft").
 * Every edit is saved to disk immediately, so there is no Save button to forget.
 * The draft is Compose state (not a Flow) so text boxes update in the same frame as you type.
 */
class AppViewModel : ViewModel() {
    val stack = mutableStateListOf<Screen>(Screen.Home)

    var draft by mutableStateOf<Macro?>(null)
        private set

    fun go(s: Screen) {
        stack.add(s)
    }

    fun back(): Boolean {
        if (stack.size <= 1) return false
        stack.removeAt(stack.lastIndex)
        if (stack.size == 1) draft = null
        return true
    }

    fun openMacro(id: String) {
        val m = Graph.macros.get(id) ?: return
        draft = m
        go(Screen.MacroEditor)
    }

    fun newMacro() {
        val m = Macro()
        Graph.macros.save(m)
        openMacro(m.id)
    }

    // ---- editing the draft ----

    fun edit(f: (Macro) -> Macro) {
        val current = draft ?: return
        val next = f(current)
        draft = next
        Graph.macros.save(next)
    }

    fun replaceDraft(m: Macro) {
        val keepId = draft?.id ?: return
        edit { m.copy(id = keepId) }
    }

    fun editStep(stepId: String, f: (Step) -> Step) = edit { m ->
        m.copy(steps = m.steps.map { if (it.id == stepId) f(it) else it })
    }

    fun addStep(type: String): Step {
        val s = Step(type = type)
        edit { it.copy(steps = it.steps + s) }
        return s
    }

    fun moveStep(stepId: String, delta: Int) = edit { m ->
        val list = m.steps.toMutableList()
        val i = list.indexOfFirst { it.id == stepId }
        val j = i + delta
        if (i < 0 || j < 0 || j >= list.size) {
            m
        } else {
            val item = list.removeAt(i)
            list.add(j, item)
            m.copy(steps = list)
        }
    }

    fun duplicateStep(stepId: String) = edit { m ->
        val i = m.steps.indexOfFirst { it.id == stepId }
        if (i < 0) {
            m
        } else {
            val copy = m.steps[i].copy(id = Ids.new())
            val list = m.steps.toMutableList()
            list.add(i + 1, copy)
            m.copy(steps = list)
        }
    }

    fun deleteStep(stepId: String) = edit { m -> m.copy(steps = m.steps.filter { it.id != stepId }) }
}
