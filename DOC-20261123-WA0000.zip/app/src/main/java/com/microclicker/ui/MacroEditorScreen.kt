package com.microclicker.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.microclicker.core.Actions
import com.microclicker.core.Delay
import com.microclicker.core.Graph
import com.microclicker.core.Guard
import com.microclicker.core.Humanize
import com.microclicker.core.HumanizePresets
import com.microclicker.core.Macro
import com.microclicker.core.Params
import com.microclicker.core.Step
import com.microclicker.core.defaults

@Composable
fun MacroEditorScreen(vm: AppViewModel) {
    val m = vm.draft
    var showAdd by remember { mutableStateOf(false) }
    if (m == null) {
        Text("Nothing to edit")
        return
    }
    var name by remember(m.id) { mutableStateOf(m.name) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 48.dp)) {
        item {
            ScreenHeader("Edit macro", onBack = { vm.back() })
        }
        item {
            TextInput(
                label = "Macro name",
                value = name,
                onChange = {
                    name = it
                    vm.edit { cur -> cur.copy(name = it) }
                },
                modifier = Modifier.padding(horizontal = 16.dp),
            )
        }

        // ---------------- steps first: it's the main thing ----------------
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Steps", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
                Button(onClick = { showAdd = true }) { Text("＋ Add step") }
            }
            HelpText(
                "Steps run top to bottom, then the macro starts over (one pass = one cycle).",
                Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
        }
        if (m.steps.isEmpty()) {
            item { HelpText("No steps yet. Tap Add step.", Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) }
        }
        itemsIndexed(m.steps, key = { _, s -> s.id }) { i, s ->
            StepRow(vm, i, s, m.steps.size)
        }

        // ---------------- macro-wide settings ----------------
        item { Spacer16() }
        item { LoopCard(vm, m) }
        item { HumanizeCard(vm, m) }
        item { GuardCard(vm, m) }

        item {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                OutlinedButton(onClick = { vm.go(Screen.JsonEditor) }) { Text("{ } Edit as JSON") }
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Add a step") },
            text = {
                LazyColumn(Modifier.height(380.dp)) {
                    items(Actions.topLevel(), key = { it.type }) { a ->
                        Column(
                            Modifier.fillMaxWidth().clickable {
                                showAdd = false
                                val s = vm.addStep(a.type)
                                vm.go(Screen.StepEditor(s.id))
                            }.padding(vertical = 10.dp),
                        ) {
                            Text("${a.icon}  ${a.label}", style = MaterialTheme.typography.titleSmall)
                            HelpText(a.description)
                        }
                        HorizontalDivider()
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Spacer16() {
    androidx.compose.foundation.layout.Spacer(Modifier.height(16.dp))
}

@Composable
private fun StepRow(vm: AppViewModel, index: Int, s: Step, total: Int) {
    val action = Actions.get(s.type)
    val summary = action?.summary(Params(s.params, action.defaults)) ?: ""
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
            .clickable { vm.go(Screen.StepEditor(s.id)) },
    ) {
        Column(Modifier.padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "${index + 1}. ${action?.icon ?: "?"}  ${stepTitle(s)}",
                        style = MaterialTheme.typography.titleSmall,
                    )
                    if (summary.isNotBlank()) HelpText(summary)
                    val bits = buildList {
                        if (s.conditions.isNotEmpty()) add("⚙ ${s.conditions.size} condition(s)")
                        val a = s.timing.after
                        if (a.maxMs > a.minMs) add("⏱ ${a.minMs}–${a.maxMs} ms") else add("⏱ ${a.minMs} ms")
                    }
                    HelpText(bits.joinToString("  ·  "))
                }
                Switch(checked = s.enabled, onCheckedChange = { on -> vm.editStep(s.id) { it.copy(enabled = on) } })
            }
            Row {
                SmallBtn("▲") { vm.moveStep(s.id, -1) }
                SmallBtn("▼") { vm.moveStep(s.id, +1) }
                SmallBtn("⧉") { vm.duplicateStep(s.id) }
                SmallBtn("🗑") { vm.deleteStep(s.id) }
            }
        }
    }
}

@Composable
private fun LoopCard(vm: AppViewModel, m: Macro) {
    SectionCard("🔁 Repeating") {
        IntInput(
            "Number of cycles", m.loop.cycles.toLong(),
            { v -> vm.edit { cur -> cur.copy(loop = cur.loop.copy(cycles = v.toInt())) } },
            help = "0 = keep going until you stop it.",
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IntInput(
                "Pause between cycles: min", m.loop.gap.minMs,
                { v -> vm.edit { cur -> cur.copy(loop = cur.loop.copy(gap = cur.loop.gap.copy(minMs = v))) } },
                Modifier.weight(1f), unit = "ms",
            )
            IntInput(
                "max", m.loop.gap.maxMs,
                { v -> vm.edit { cur -> cur.copy(loop = cur.loop.copy(gap = cur.loop.gap.copy(maxMs = v))) } },
                Modifier.weight(1f), unit = "ms",
            )
        }
        HelpText("Max bigger than min = a random pause every cycle.")
        IntInput(
            "Stop by itself after", m.loop.maxRuntimeSec.toLong(),
            { v -> vm.edit { cur -> cur.copy(loop = cur.loop.copy(maxRuntimeSec = v.toInt())) } },
            unit = "sec", help = "0 = no limit.",
        )
    }
}

@Composable
private fun HumanizeCard(vm: AppViewModel, m: Macro) {
    val h = m.humanize
    var version by remember { mutableIntStateOf(0) }
    fun upd(f: (Humanize) -> Humanize) = vm.edit { cur -> cur.copy(humanize = f(cur.humanize)) }
    fun preset(p: Humanize) {
        upd { p }
        version++
    }

    SectionCard("🎲 Look human (random)") {
        HelpText(
            "Against AFK / bot checks: random delays, taps that land a few pixels off, uneven press times, " +
                "curved swipes and the odd long pause. Random min–max ranges on each step always work, even with this off."
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { preset(HumanizePresets.OFF) }) { Text("Off") }
            OutlinedButton(onClick = { preset(HumanizePresets.LIGHT) }) { Text("Light") }
            OutlinedButton(onClick = { preset(HumanizePresets.STRONG) }) { Text("Strong") }
        }
        SwitchRow("Extra randomness on", h.enabled, { on -> upd { it.copy(enabled = on) } })
        if (h.enabled) {
            IntInput("Delays vary by up to", h.timingJitterPct.toLong(), { v -> upd { it.copy(timingJitterPct = v.toInt()) } }, unit = "%", resetKey = version)
            IntInput("Taps land up to", h.positionJitterPx.toLong(), { v -> upd { it.copy(positionJitterPx = v.toInt()) } }, unit = "px away", resetKey = version)
            IntInput("Press time varies by up to", h.holdJitterPct.toLong(), { v -> upd { it.copy(holdJitterPct = v.toInt()) } }, unit = "%", resetKey = version)
            IntInput("Chance of a long pause (per step)", h.pauseChancePct.toLong(), { v -> upd { it.copy(pauseChancePct = v.toInt()) } }, unit = "%", resetKey = version)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IntInput("Pause min", h.pauseMinSec.toLong(), { v -> upd { it.copy(pauseMinSec = v.toInt()) } }, Modifier.weight(1f), unit = "s", resetKey = version)
                IntInput("Pause max", h.pauseMaxSec.toLong(), { v -> upd { it.copy(pauseMaxSec = v.toInt()) } }, Modifier.weight(1f), unit = "s", resetKey = version)
            }
            SwitchRow("Curved swipes", h.swipeCurve, { on -> upd { it.copy(swipeCurve = on) } })
        }
    }
}

@Composable
private fun GuardCard(vm: AppViewModel, m: Macro) {
    val ctx = LocalContext.current
    val g = m.guard
    var addingBlocked by remember { mutableStateOf(false) }
    var wordsText by remember(m.id) { mutableStateOf(m.guard.blockedUrlWords.joinToString(", ")) }
    fun upd(f: (Guard) -> Guard) = vm.edit { cur -> cur.copy(guard = f(cur.guard)) }

    SectionCard("🛡 Guard (keep it out of trouble)") {
        HelpText(
            "After a tap, the guard checks where the phone ended up. If a click threw you into a blocked app " +
                "or website, it goes back (or opens something else) and the photo step can try the next copy."
        )
        SwitchRow("Guard on", g.enabled, { on -> upd { it.copy(enabled = on) } })
        if (g.enabled) {
            Text("Never allow these apps in front:", style = MaterialTheme.typography.labelLarge)
            g.blockedPackages.forEach { pkg ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(appLabel(ctx, pkg), Modifier.weight(1f))
                    SmallBtn("✕") { upd { it.copy(blockedPackages = it.blockedPackages - pkg) } }
                }
            }
            OutlinedButton(onClick = { addingBlocked = true }) { Text("＋ Block an app (e.g. your browser)") }

            TextInput(
                label = "Block websites containing (comma separated)",
                value = wordsText,
                onChange = { t ->
                    wordsText = t
                    upd { it.copy(blockedUrlWords = t.split(',').map { w -> w.trim() }.filter { w -> w.isNotEmpty() }) }
                },
                help = "Works in browsers that show their address bar (Chrome, Samsung Internet, Firefox, Edge…). " +
                    "Otherwise block the browser app above.",
            )

            AppChooser(
                "Stay inside this app (optional)", g.onlyPackage,
                { pkg -> upd { it.copy(onlyPackage = pkg) } },
                help = "If any other app comes to the front, it counts as a violation.",
            )

            ChoiceDropdown(
                label = "When that happens",
                options = listOf(
                    "back" to "Press Back",
                    "open_app" to "Open an app",
                    "open_url" to "Open a link",
                    "stop" to "Stop the macro",
                ),
                value = g.recovery,
                onChange = { r -> upd { it.copy(recovery = r) } },
            )
            when (g.recovery) {
                "open_app" -> AppChooser("App to open", g.recoveryTarget, { pkg -> upd { it.copy(recoveryTarget = pkg) } })
                "open_url" -> TextInput("Link to open", g.recoveryTarget, { t -> upd { it.copy(recoveryTarget = t) } })
                else -> Unit
            }
            IntInput(
                "Wait before checking", g.settleMs,
                { v -> upd { it.copy(settleMs = v) } },
                unit = "ms", help = "Give a new page time to load before the guard looks.",
            )
        }
    }

    if (addingBlocked) {
        AppPickerDialog(
            onDismiss = { addingBlocked = false },
            onChoose = { pkg ->
                addingBlocked = false
                upd { it.copy(blockedPackages = (it.blockedPackages + pkg).distinct()) }
            },
        )
    }
}

/** Raw JSON view of the macro, for power users and for pasting in changes. */
@Composable
fun JsonEditorScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val m = vm.draft
    var text by remember { mutableStateOf(if (m != null) Graph.macros.toJson(m) else "") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Macro as JSON", onBack = { vm.back() })
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
            textStyle = TextStyle(fontFamily = FontFamily.Monospace),
        )
        error?.let {
            Text(it, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                runCatching { Graph.macros.parse(text) }
                    .onSuccess {
                        vm.replaceDraft(it)
                        error = null
                        ctx.toast("Applied")
                    }
                    .onFailure { error = "Not valid: ${it.message}" }
            }) { Text("Apply") }
            OutlinedButton(onClick = {
                clipboard.setText(AnnotatedString(text))
                ctx.toast("Copied")
            }) { Text("Copy") }
        }
    }
}
