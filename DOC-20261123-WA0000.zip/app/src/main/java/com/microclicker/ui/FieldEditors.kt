package com.microclicker.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.microclicker.conditions.Conditions
import com.microclicker.conditions.ValueKind
import com.microclicker.core.Actions
import com.microclicker.core.Condition
import com.microclicker.core.Field
import com.microclicker.core.Graph
import com.microclicker.core.Kind
import com.microclicker.core.Params
import com.microclicker.core.Step
import com.microclicker.core.defaults
import com.microclicker.data.PickKind
import com.microclicker.data.PickResult

/** Asks the screen overlay for something; the mapper turns the answer into param updates (key to value). */
typealias PickRequester = (PickKind, (PickResult) -> List<Pair<String, Any?>>) -> Unit

/**
 * Builds the settings form for an action straight from its field list.
 * This is why adding a new action never needs any UI code.
 *
 * [p] holds the values for THIS level (nested actions get their own, prefix-stripped, level).
 * [onSet] receives keys relative to this level.
 */
@Composable
fun FieldsEditor(
    fields: List<Field>,
    p: Params,
    selfMacroId: String,
    onSet: (String, Any?) -> Unit,
    onPick: PickRequester,
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        for (f in fields) {
            if (f.showIf?.invoke(p) == false) continue
            FieldRow(f, p, selfMacroId, onSet, onPick)
        }
    }
}

@Composable
private fun FieldRow(
    f: Field,
    p: Params,
    selfMacroId: String,
    onSet: (String, Any?) -> Unit,
    onPick: PickRequester,
) {
    when (f.kind) {
        Kind.INT, Kind.DECIMAL, Kind.TEXT -> {
            val shown = p.stored(f.key) ?: f.default
            TextInput(
                label = f.label,
                value = shown,
                onChange = { t ->
                    val v: Any = when (f.kind) {
                        Kind.INT -> numberValue(t, false)
                        Kind.DECIMAL -> numberValue(t, true)
                        else -> t
                    }
                    onSet(f.key, v)
                },
                keyboard = when (f.kind) {
                    Kind.INT -> KeyboardType.Number
                    Kind.DECIMAL -> KeyboardType.Decimal
                    else -> KeyboardType.Text
                },
                unit = f.unit,
                help = f.help,
            )
        }

        Kind.BOOL -> SwitchRow(f.label, p.bool(f.key), { onSet(f.key, it) }, f.help)

        Kind.CHOICE -> ChoiceDropdown(f.label, f.options, p.str(f.key), { onSet(f.key, it) }, help = f.help)

        Kind.TEMPLATE -> Column {
            TemplateChooser(
                label = f.label,
                templateId = p.str(f.key),
                onChoose = { onSet(f.key, it) },
                onCapture = { onPick(PickKind.CAPTURE) { r -> listOf(f.key to r.templateId) } },
            )
            if (f.help.isNotEmpty()) HelpText(f.help)
        }

        Kind.APP -> AppChooser(f.label, p.str(f.key), { onSet(f.key, it) }, f.help)

        Kind.MACRO -> {
            val macros by Graph.macros.macros.collectAsState()
            val options = listOf("" to "(none)") + macros.filter { it.id != selfMacroId }.map { it.id to it.name }
            ChoiceDropdown(f.label, options, p.str(f.key), { onSet(f.key, it) }, help = f.help)
        }

        Kind.POINTS -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            TextInput(
                label = f.label,
                value = p.stored(f.key) ?: f.default,
                onChange = { onSet(f.key, it) },
                help = f.help,
                singleLine = false,
            )
            OutlinedButton(onClick = {
                onPick(PickKind.POINT_LIST) { r -> listOf(f.key to appendPoint(p.stored(f.key) ?: "", r.x1, r.y1)) }
            }) { Text("📍 Add a spot from the screen") }
        }

        Kind.PICK_TAP -> OutlinedButton(
            onClick = { onPick(PickKind.TAP) { r -> listOf("x" to r.x1, "y" to r.y1) } },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("📍 ${f.label}") }

        Kind.PICK_SWIPE -> OutlinedButton(
            onClick = {
                onPick(PickKind.SWIPE) { r ->
                    listOf("x" to r.x1, "y" to r.y1, "x2" to r.x2, "y2" to r.y2, "duration" to r.durationMs)
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("✍ ${f.label}") }

        Kind.NESTED -> {
            val nestedType = p.str(f.key)
            val nested = Actions.get(nestedType)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ChoiceDropdown(
                    label = f.label,
                    options = Actions.nestable().map { it.type to it.label },
                    value = nestedType,
                    onChange = { onSet(f.key, it) },
                )
                if (nested != null) {
                    HelpText(nested.description)
                    if (nested.fields.isNotEmpty()) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                FieldsEditor(
                                    fields = nested.fields,
                                    p = p.sub("${f.key}.", nested.defaults),
                                    selfMacroId = selfMacroId,
                                    onSet = { k, v -> onSet("${f.key}.$k", v) },
                                    onPick = { kind, mapper ->
                                        onPick(kind) { r -> mapper(r).map { (k, v) -> "${f.key}.$k" to v } }
                                    },
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * The "only run this step when…" list. All conditions must be true.
 * [onCapture] asks the screen for a new photo and hands the answer to the given callback.
 */
@Composable
fun ConditionsEditor(
    step: Step,
    allSteps: List<Step>,
    onChange: (List<Condition>) -> Unit,
    onCapture: ((PickResult) -> Unit) -> Unit,
) {
    val list = step.conditions

    fun update(i: Int, c: Condition) = onChange(list.toMutableList().also { it[i] = c })
    fun remove(i: Int) = onChange(list.filterIndexed { idx, _ -> idx != i })

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (list.isEmpty()) HelpText("No conditions: this step runs every time it's reached.")

        list.forEachIndexed { i, c ->
            val t = Conditions.get(c.type)
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        ChoiceDropdown(
                            label = "Only run when",
                            options = Conditions.all().map { it.type to it.label },
                            value = c.type,
                            onChange = { nt ->
                                val ct = Conditions.get(nt)
                                update(i, Condition(nt, ct?.valueDefault ?: "", ct?.secondDefault ?: ""))
                            },
                            modifier = Modifier.weight(1f),
                        )
                        SmallBtn("🗑") { remove(i) }
                    }
                    when (t?.kind) {
                        ValueKind.NUMBER -> TextInput(
                            label = "Value",
                            value = c.value,
                            onChange = { update(i, c.copy(value = it)) },
                            keyboard = KeyboardType.Number,
                            help = t?.hint ?: "",
                        )

                        ValueKind.TEMPLATE -> TemplateChooser(
                            label = "Photo",
                            templateId = c.value,
                            onChoose = { update(i, c.copy(value = it)) },
                            onCapture = { onCapture { r -> update(i, c.copy(value = r.templateId)) } },
                        )

                        ValueKind.STEP -> {
                            val options = listOf("" to "(choose a step)") +
                                allSteps.mapIndexedNotNull { idx, s ->
                                    if (s.id == step.id) null else s.id to "${idx + 1}. ${stepTitle(s)}"
                                }
                            ChoiceDropdown("Step", options, c.value, { update(i, c.copy(value = it)) })
                        }

                        ValueKind.APP -> AppChooser("App", c.value, { update(i, c.copy(value = it)) })

                        null -> Text("Unknown condition \"${c.type}\" (ignored when running)")
                    }
                    val second = t?.secondLabel
                    if (second != null) {
                        TextInput(
                            label = second,
                            value = c.value2,
                            onChange = { update(i, c.copy(value2 = it)) },
                        )
                    }
                }
            }
        }

        val first = Conditions.all().first()
        TextButton(onClick = {
            onChange(list + Condition(first.type, first.valueDefault, first.secondDefault))
        }) { Text("＋ Add a condition") }
    }
}
