package com.microclicker.ui

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.microclicker.core.Engine
import com.microclicker.core.Graph
import com.microclicker.core.Macro
import com.microclicker.data.Packs

@Composable
fun HomeScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val macros by Graph.macros.macros.collectAsState()
    val run by Engine.state.collectAsState()
    val ready by Engine.serviceReady.collectAsState()
    val selected by Graph.prefs.selectedMacroId.collectAsState()
    val bubble by Graph.prefs.showBubble.collectAsState()
    val log by Engine.logLines.collectAsState()

    var deleteTarget by remember { mutableStateOf<Macro?>(null) }
    var exportTarget by remember { mutableStateOf<Macro?>(null) }
    var showPaste by remember { mutableStateOf(false) }
    var showLog by remember { mutableStateOf(false) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                val text = ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                Packs.import(text)
            }.onSuccess { ctx.toast("Imported \"${it.name}\"") }
                .onFailure { ctx.toast("That file isn't a valid macro") }
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val m = exportTarget
        if (uri != null && m != null) {
            runCatching {
                ctx.contentResolver.openOutputStream(uri)!!.bufferedWriter().use { it.write(Packs.export(m)) }
            }.onSuccess { ctx.toast("Saved") }
                .onFailure { ctx.toast("Couldn't save the file") }
        }
        exportTarget = null
    }

    fun runFromApp(m: Macro) {
        if (!ready) {
            ctx.toast("Turn on the accessibility service first")
            return
        }
        Graph.prefs.selectMacro(m.id)
        Engine.startAfter(m.id, 3000L)
        ctx.toast("Starting in 3 seconds. Switch to the app you want to click in.")
        ctx.findActivity()?.moveTaskToBack(true)
    }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { vm.newMacro() }) { Text("＋  New macro") }
        },
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(bottom = 96.dp),
        ) {
            item {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
                    Text("Micro Clicker", style = MaterialTheme.typography.headlineMedium)
                    HelpText("Photo, link and auto-click macros with random timing.")
                }
            }

            item {
                SectionCard("Status") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (ready) "✅ Accessibility service is ON" else "⚠️ Accessibility service is OFF",
                            Modifier.weight(1f),
                        )
                    }
                    if (!ready) {
                        HelpText(
                            "Micro Clicker needs it to tap, swipe and see the screen. " +
                                "Open Accessibility settings, find Micro Clicker and turn it on."
                        )
                        Button(onClick = {
                            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }) { Text("Open Accessibility settings") }
                        HelpText(
                            "Switch greyed out (Android 13+)? Open Settings > Apps > Micro Clicker, " +
                                "tap the ⋮ menu and choose \"Allow restricted settings\", then try again."
                        )
                    }
                    if (!Graph.openCvReady) {
                        Text("⚠️ The photo-matching engine failed to load on this phone.", color = MaterialTheme.colorScheme.error)
                    }
                    SwitchRow(
                        "Floating control", bubble, { Graph.prefs.setBubble(it) },
                        "Small always-on-top button: ▶/■ to run, 📷 to capture a photo, 🎯 to pick a spot.",
                    )
                }
            }

            if (run.running) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("▶ Running: ${run.macroName}", style = MaterialTheme.typography.titleMedium)
                            Text("Cycle ${run.cycle}" + if (run.step.isNotEmpty()) "  ·  ${run.step}" else "")
                            Button(
                                onClick = { Engine.stop() },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            ) { Text("■ Stop") }
                        }
                    }
                }
            }

            item {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedButton(onClick = { vm.go(Screen.Photos) }) { Text("🖼 Photos") }
                    OutlinedButton(onClick = {
                        importLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                    }) { Text("📂 Import") }
                    OutlinedButton(onClick = { showPaste = true }) { Text("📋 Paste") }
                }
            }

            item {
                Text(
                    "Your macros",
                    Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.titleMedium,
                )
            }

            if (macros.isEmpty()) {
                item { HelpText("No macros yet. Tap New macro.", Modifier.padding(horizontal = 20.dp)) }
            }

            items(macros, key = { it.id }) { m ->
                MacroCard(
                    m = m,
                    selected = m.id == selected,
                    running = run.running && run.macroId == m.id,
                    onSelect = { Graph.prefs.selectMacro(m.id) },
                    onRun = { runFromApp(m) },
                    onStop = { Engine.stop() },
                    onEdit = { vm.openMacro(m.id) },
                    onDuplicate = { Graph.macros.duplicate(m.id) },
                    onExport = {
                        exportTarget = m
                        exportLauncher.launch(m.name.replace(Regex("[^A-Za-z0-9 _-]"), "_") + ".microclicker.json")
                    },
                    onCopy = {
                        clipboard.setText(AnnotatedString(Packs.export(m)))
                        ctx.toast("Copied. Paste it anywhere to share.")
                    },
                    onDelete = { deleteTarget = m },
                )
            }

            item {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    TextButton(onClick = { showLog = !showLog }) {
                        Text(if (showLog) "▾ Activity log" else "▸ Activity log (${log.size})")
                    }
                    if (showLog) {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                if (log.isEmpty()) HelpText("Nothing yet.")
                                log.takeLast(25).forEach {
                                    Text(it, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
                                }
                                TextButton(onClick = { Engine.clearLog() }) { Text("Clear") }
                            }
                        }
                    }
                }
            }
        }
    }

    deleteTarget?.let { m ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete \"${m.name}\"?") },
            text = { Text("This can't be undone. (Your photos stay in the library.)") },
            confirmButton = {
                TextButton(onClick = {
                    Graph.macros.delete(m.id)
                    deleteTarget = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } },
        )
    }

    if (showPaste) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPaste = false },
            title = { Text("Paste a macro") },
            text = {
                TextInput("Macro JSON", text, { text = it }, singleLine = false)
            },
            confirmButton = {
                TextButton(onClick = {
                    runCatching { Packs.import(text) }
                        .onSuccess {
                            ctx.toast("Imported \"${it.name}\"")
                            showPaste = false
                        }
                        .onFailure { ctx.toast("That isn't a valid macro") }
                }) { Text("Import") }
            },
            dismissButton = { TextButton(onClick = { showPaste = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun MacroCard(
    m: Macro,
    selected: Boolean,
    running: Boolean,
    onSelect: () -> Unit,
    onRun: () -> Unit,
    onStop: () -> Unit,
    onEdit: () -> Unit,
    onDuplicate: () -> Unit,
    onExport: () -> Unit,
    onCopy: () -> Unit,
    onDelete: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(m.name, style = MaterialTheme.typography.titleMedium)
                    val bits = buildList {
                        add("${m.steps.size} step(s)")
                        if (m.humanize.enabled) add("random")
                        if (m.guard.enabled) add("guard")
                    }
                    HelpText(bits.joinToString("  ·  "))
                }
                Row(
                    Modifier.clickable(onClick = onSelect),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = selected, onClick = onSelect)
                    Text("Floating ▶", style = MaterialTheme.typography.labelSmall)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (running) {
                    Button(
                        onClick = onStop,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    ) { Text("■ Stop") }
                } else {
                    Button(onClick = onRun) { Text("▶ Run") }
                }
                OutlinedButton(onClick = onEdit) { Text("Edit") }
                Box {
                    TextButton(onClick = { menu = true }) { Text("⋯") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Duplicate") }, onClick = { menu = false; onDuplicate() })
                        DropdownMenuItem(text = { Text("Save to file") }, onClick = { menu = false; onExport() })
                        DropdownMenuItem(text = { Text("Copy to share") }, onClick = { menu = false; onCopy() })
                        DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; onDelete() })
                    }
                }
            }
        }
    }
}
