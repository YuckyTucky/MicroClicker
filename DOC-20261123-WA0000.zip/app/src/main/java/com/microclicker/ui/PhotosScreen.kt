package com.microclicker.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.microclicker.core.Engine
import com.microclicker.core.Graph
import com.microclicker.data.PickBridge
import com.microclicker.data.PickKind
import com.microclicker.data.Template

/** The photo library: see, rename, delete, and add photos (from the screen or the gallery). */
@Composable
fun PhotosScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val templates by Graph.templates.templates.collectAsState()
    val result by PickBridge.result.collectAsState()
    var pendingToken by remember { mutableStateOf<Long?>(null) }
    var rename by remember { mutableStateOf<Template?>(null) }
    var delete by remember { mutableStateOf<Template?>(null) }

    LaunchedEffect(result) {
        val r = result
        val t = pendingToken
        if (r != null && t != null && r.token == t && r.kind == PickKind.CAPTURE) {
            pendingToken = null
            PickBridge.clear()
        }
    }
    DisposableEffect(Unit) {
        onDispose { PickBridge.clear() }
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val t = runCatching {
                ctx.contentResolver.openInputStream(uri)?.use { Graph.templates.importFrom(it) }
            }.getOrNull()
            ctx.toast(if (t != null) "Added \"${t.name}\"" else "Couldn't read that image")
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Photo library", onBack = { vm.back() })
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                if (!Engine.serviceReady.value) {
                    ctx.toast("Turn on the accessibility service first")
                } else {
                    pendingToken = PickBridge.ask(PickKind.CAPTURE).token
                    ctx.toast("Go to the right screen, then tap 📷 on the floating control")
                    ctx.findActivity()?.moveTaskToBack(true)
                }
            }) { Text("📷 From screen") }
            OutlinedButton(onClick = { gallery.launch("image/*") }) { Text("🖼 From gallery") }
        }
        HelpText(
            "Tip: crop tightly around the thing you want to find, and avoid parts that change (numbers, timers, animations).",
            Modifier.padding(16.dp),
        )

        if (templates.isEmpty()) {
            HelpText("No photos yet.", Modifier.padding(horizontal = 16.dp))
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(120.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(templates, key = { it.id }) { t ->
                Card(Modifier.fillMaxWidth()) {
                    Column(
                        Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        TemplateThumb(t.id, Modifier.size(96.dp))
                        Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                        Row {
                            SmallBtn("✎") { rename = t }
                            SmallBtn("🗑") { delete = t }
                        }
                    }
                }
            }
        }
    }

    rename?.let { t ->
        var text by remember(t.id) { mutableStateOf(t.name) }
        AlertDialog(
            onDismissRequest = { rename = null },
            title = { Text("Rename photo") },
            text = { TextInput("Name", text, { text = it }) },
            confirmButton = {
                TextButton(onClick = {
                    Graph.templates.rename(t.id, text)
                    rename = null
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { rename = null }) { Text("Cancel") } },
        )
    }

    delete?.let { t ->
        AlertDialog(
            onDismissRequest = { delete = null },
            title = { Text("Delete \"${t.name}\"?") },
            text = { Text("Steps that use this photo will skip until you choose another.") },
            confirmButton = {
                TextButton(onClick = {
                    Graph.templates.delete(t.id)
                    delete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { delete = null }) { Text("Cancel") } },
        )
    }
}
