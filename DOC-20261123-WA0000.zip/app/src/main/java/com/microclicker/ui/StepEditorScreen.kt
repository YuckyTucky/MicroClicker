package com.microclicker.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.microclicker.core.Actions
import com.microclicker.core.Engine
import com.microclicker.core.Params
import com.microclicker.core.defaults
import com.microclicker.data.PickBridge
import com.microclicker.data.PickKind
import com.microclicker.data.PickResult

/** A pick we asked the screen overlay for, and what to do with the answer. */
private class PickTarget(val token: Long, val apply: (PickResult) -> Unit)

@Composable
fun StepEditorScreen(vm: AppViewModel, stepId: String) {
    val ctx = LocalContext.current
    val macro = vm.draft
    val step = macro?.steps?.firstOrNull { it.id == stepId }

    var pending by remember { mutableStateOf<PickTarget?>(null) }
    val result by PickBridge.result.collectAsState()

    // The overlay (in the accessibility service) answers through PickBridge; apply it when it matches our request.
    LaunchedEffect(result) {
        val r = result
        val t = pending
        if (r != null && t != null && r.token == t.token) {
            t.apply(r)
            pending = null
            PickBridge.clear()
        }
    }
    DisposableEffect(Unit) {
        onDispose { PickBridge.clear() }
    }

    if (macro == null || step == null) {
        // The step was deleted (or the draft is gone): leave.
        LaunchedEffect(Unit) { vm.back() }
        return
    }
    val action = Actions.get(step.type)

    fun startPick(kind: PickKind, apply: (PickResult) -> Unit) {
        if (!Engine.serviceReady.value) {
            ctx.toast("Turn on the accessibility service first")
            return
        }
        val req = PickBridge.ask(kind)
        pending = PickTarget(req.token, apply)
        ctx.toast(
            if (kind == PickKind.CAPTURE) "Go to the right screen, then tap 📷 on the floating control"
            else "Go to the right screen, then tap 🎯 on the floating control"
        )
        ctx.findActivity()?.moveTaskToBack(true)
    }

    var name by remember(step.id) { mutableStateOf(step.name) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 48.dp)) {
        item {
            ScreenHeader("${action?.icon ?: ""} ${action?.label ?: step.type}", onBack = { vm.back() })
        }

        item {
            TextInput(
                label = "Step name (optional)",
                value = name,
                onChange = { t ->
                    name = t
                    vm.editStep(step.id) { it.copy(name = t) }
                },
                modifier = Modifier.padding16(),
            )
        }

        if (action != null) {
            item {
                SectionCard(action.label) {
                    HelpText(action.description)
                    FieldsEditor(
                        fields = action.fields,
                        p = Params(step.params, action.defaults),
                        selfMacroId = macro.id,
                        onSet = { k, v ->
                            vm.editStep(step.id) { s -> s.copy(params = Params(s.params).set(k, v).obj) }
                        },
                        onPick = { kind, mapper ->
                            startPick(kind) { r ->
                                vm.editStep(step.id) { s ->
                                    var pp = Params(s.params)
                                    for ((k, v) in mapper(r)) pp = pp.set(k, v)
                                    s.copy(params = pp.obj)
                                }
                            }
                        },
                    )
                }
            }
        } else {
            item {
                SectionCard("Unknown action") {
                    HelpText("This step uses \"${step.type}\", which this version of the app doesn't have. It will be skipped.")
                }
            }
        }

        item {
            SectionCard("⏱ Timing") {
                HelpText(
                    "Wait before and after this step. Make max bigger than min and the wait is random every time."
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IntInput(
                        "Wait before: min", step.timing.before.minMs,
                        { v -> vm.editStep(step.id) { s -> s.copy(timing = s.timing.copy(before = s.timing.before.copy(minMs = v))) } },
                        Modifier.weight(1f), unit = "ms",
                    )
                    IntInput(
                        "max", step.timing.before.maxMs,
                        { v -> vm.editStep(step.id) { s -> s.copy(timing = s.timing.copy(before = s.timing.before.copy(maxMs = v))) } },
                        Modifier.weight(1f), unit = "ms",
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IntInput(
                        "Wait after: min", step.timing.after.minMs,
                        { v -> vm.editStep(step.id) { s -> s.copy(timing = s.timing.copy(after = s.timing.after.copy(minMs = v))) } },
                        Modifier.weight(1f), unit = "ms",
                    )
                    IntInput(
                        "max", step.timing.after.maxMs,
                        { v -> vm.editStep(step.id) { s -> s.copy(timing = s.timing.copy(after = s.timing.after.copy(maxMs = v))) } },
                        Modifier.weight(1f), unit = "ms",
                    )
                }
            }
        }

        item {
            SectionCard("⚙ Only run this step when…") {
                ConditionsEditor(
                    step = step,
                    allSteps = macro.steps,
                    onChange = { list -> vm.editStep(step.id) { it.copy(conditions = list) } },
                    onCapture = { apply -> startPick(PickKind.CAPTURE, apply) },
                )
            }
        }
    }
}

private fun Modifier.padding16(): Modifier = this.then(Modifier.padding(horizontal = 16.dp))
