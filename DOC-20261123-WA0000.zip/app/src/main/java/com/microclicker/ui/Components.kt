package com.microclicker.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.microclicker.core.Actions
import com.microclicker.core.Graph
import com.microclicker.core.Step
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ------------------------------------------------------------------ small helpers

fun Context.toast(msg: String) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

data class AppInfo(val label: String, val pkg: String)

/** Every app that has a launcher icon. */
@Suppress("DEPRECATION")
fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val found = pm.queryIntentActivities(intent, 0)
    return found
        .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

@Suppress("DEPRECATION")
fun appLabel(ctx: Context, pkg: String): String {
    if (pkg.isBlank()) return ""
    return try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }
}

fun stepTitle(s: Step): String = s.name.ifBlank { Actions.get(s.type)?.label ?: s.type }

/** A number is stored as a JSON number if it survives a round trip, otherwise as the raw text being typed. */
fun numberValue(text: String, decimal: Boolean): Any {
    val t = text.trim()
    if (!decimal) {
        val l = t.toLongOrNull()
        if (l != null && l.toString() == t) {
            return if (l in Int.MIN_VALUE..Int.MAX_VALUE) l.toInt() else l
        }
    } else {
        val d = t.replace(',', '.').toDoubleOrNull()
        if (d != null && d.toString() == t) return d
    }
    return text
}

fun appendPoint(existing: String, x: Int, y: Int): String {
    val head = if (existing.isBlank()) "" else existing.trim().trimEnd(';') + ";"
    return "$head$x,$y"
}

// ------------------------------------------------------------------ layout + inputs

@Composable
fun SectionCard(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
fun HelpText(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
fun ScreenHeader(title: String, onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text(
            title,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.titleLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        trailing()
    }
}

@Composable
fun SmallBtn(label: String, onClick: () -> Unit) {
    Text(
        label,
        modifier = Modifier.clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp),
        style = MaterialTheme.typography.titleMedium,
    )
}

@Composable
fun TextInput(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    keyboard: KeyboardType = KeyboardType.Text,
    unit: String = "",
    help: String = "",
    singleLine: Boolean = true,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        suffix = if (unit.isNotEmpty()) {
            { Text(unit) }
        } else {
            null
        },
        supportingText = if (help.isNotEmpty()) {
            { Text(help) }
        } else {
            null
        },
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        singleLine = singleLine,
        modifier = modifier.fillMaxWidth(),
    )
}

/**
 * A number box that owns its own text while you type (so clearing the box doesn't snap back to 0).
 * Change [resetKey] to force it to re-read [value] (e.g. after pressing a preset).
 */
@Composable
fun IntInput(
    label: String,
    value: Long,
    onChange: (Long) -> Unit,
    modifier: Modifier = Modifier,
    unit: String = "",
    help: String = "",
    resetKey: Any = Unit,
) {
    var text by remember(resetKey) { mutableStateOf(value.toString()) }
    TextInput(
        label = label,
        value = text,
        onChange = { t ->
            text = t
            onChange(t.trim().toLongOrNull() ?: 0L)
        },
        modifier = modifier,
        keyboard = KeyboardType.Number,
        unit = unit,
        help = help,
    )
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit, help: String = "") {
    Column {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
            Switch(checked = checked, onCheckedChange = onChange)
        }
        if (help.isNotEmpty()) HelpText(help)
    }
}

@Composable
fun ChoiceDropdown(
    label: String,
    options: List<Pair<String, String>>,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    help: String = "",
) {
    var open by remember { mutableStateOf(false) }
    val shown = options.firstOrNull { it.first == value }?.second ?: value
    Column(modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
                Text(shown.ifEmpty { "Choose…" }, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("▾")
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { (v, l) ->
                    DropdownMenuItem(text = { Text(l) }, onClick = {
                        onChange(v)
                        open = false
                    })
                }
            }
        }
        if (help.isNotEmpty()) HelpText(help)
    }
}

// ------------------------------------------------------------------ photos

@Composable
fun TemplateThumb(id: String, modifier: Modifier = Modifier) {
    val bmp: Bitmap? by produceState<Bitmap?>(null, id) {
        value = withContext(Dispatchers.IO) { Graph.templates.thumb(id) }
    }
    val b = bmp
    if (b != null) {
        Image(
            bitmap = b.asImageBitmap(),
            contentDescription = null,
            modifier = modifier,
            contentScale = ContentScale.Fit,
        )
    } else {
        Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant))
    }
}

/** A "photo" input: thumbnail + name + Choose button. */
@Composable
fun TemplateChooser(
    label: String,
    templateId: String,
    onChoose: (String) -> Unit,
    onCapture: () -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    val templates by Graph.templates.templates.collectAsState()
    val current = templates.firstOrNull { it.id == templateId }

    Column(Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (current != null) {
                TemplateThumb(current.id, Modifier.size(56.dp))
            } else {
                Box(Modifier.size(56.dp).background(MaterialTheme.colorScheme.surfaceVariant))
            }
            Text(
                current?.name ?: "No photo chosen",
                Modifier.weight(1f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Button(onClick = { open = true }) { Text(if (current != null) "Change" else "Choose") }
        }
    }

    if (open) {
        TemplatePickerDialog(
            onDismiss = { open = false },
            onChoose = {
                open = false
                onChoose(it)
            },
            onCapture = {
                open = false
                onCapture()
            },
        )
    }
}

@Composable
fun TemplatePickerDialog(onDismiss: () -> Unit, onChoose: (String) -> Unit, onCapture: () -> Unit) {
    val ctx = LocalContext.current
    val templates by Graph.templates.templates.collectAsState()
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val t = runCatching {
                ctx.contentResolver.openInputStream(uri)?.use { Graph.templates.importFrom(it) }
            }.getOrNull()
            if (t != null) onChoose(t.id) else ctx.toast("Couldn't read that image")
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose a photo") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onCapture) { Text("📷 From screen") }
                    OutlinedButton(onClick = { gallery.launch("image/*") }) { Text("🖼 Gallery") }
                }
                HelpText("From screen: the app hides, you open the right screen and tap 📷 on the floating control, then draw a box around the thing.")
                if (templates.isEmpty()) {
                    Text("No photos yet. Add one with the buttons above.")
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(88.dp),
                        modifier = Modifier.height(280.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        gridItems(templates, key = { it.id }) { t ->
                            Column(
                                Modifier.clickable { onChoose(t.id) },
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                TemplateThumb(t.id, Modifier.size(80.dp))
                                Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

// ------------------------------------------------------------------ apps

/** An "app" input: name + Choose button (+ clear). Stores the package name. */
@Composable
fun AppChooser(label: String, pkg: String, onChoose: (String) -> Unit, help: String = "") {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                if (pkg.isBlank()) "Not set" else appLabel(ctx, pkg),
                Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (pkg.isNotBlank()) SmallBtn("✕") { onChoose("") }
            Button(onClick = { open = true }) { Text(if (pkg.isBlank()) "Choose app" else "Change") }
        }
        if (help.isNotEmpty()) HelpText(help)
    }
    if (open) {
        AppPickerDialog(
            onDismiss = { open = false },
            onChoose = {
                open = false
                onChoose(it)
            },
        )
    }
}

@Composable
fun AppPickerDialog(onDismiss: () -> Unit, onChoose: (String) -> Unit) {
    val ctx = LocalContext.current
    val apps = remember { loadApps(ctx) }
    var query by remember { mutableStateOf("") }
    val q = query.trim().lowercase()
    val shown = if (q.isEmpty()) apps else apps.filter { it.label.lowercase().contains(q) || it.pkg.lowercase().contains(q) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose an app") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextInput("Search (or type a package name)", query, { query = it })
                if (q.contains('.') && shown.none { it.pkg.lowercase() == q }) {
                    TextButton(onClick = { onChoose(query.trim()) }) { Text("Use \"${query.trim()}\" as package name") }
                }
                LazyColumn(Modifier.height(320.dp)) {
                    items(shown, key = { it.pkg }) { app ->
                        Column(Modifier.fillMaxWidth().clickable { onChoose(app.pkg) }.padding(vertical = 8.dp)) {
                            Text(app.label, style = MaterialTheme.typography.bodyLarge)
                            HelpText(app.pkg)
                        }
                        HorizontalDivider()
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
