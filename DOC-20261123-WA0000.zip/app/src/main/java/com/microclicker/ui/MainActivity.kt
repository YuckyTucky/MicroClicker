package com.microclicker.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                AppRoot(vm)
            }
        }
    }
}

@Composable
fun AppRoot(vm: AppViewModel) {
    BackHandler(enabled = vm.stack.size > 1) { vm.back() }

    Surface(Modifier.fillMaxSize()) {
        when (val screen = vm.stack.last()) {
            Screen.Home -> HomeScreen(vm)
            Screen.MacroEditor -> MacroEditorScreen(vm)
            is Screen.StepEditor -> StepEditorScreen(vm, screen.stepId)
            Screen.Photos -> PhotosScreen(vm)
            Screen.JsonEditor -> JsonEditorScreen(vm)
        }
    }
}
