package com.microclicker.core

import android.app.Application
import com.microclicker.data.MacroRepository
import com.microclicker.data.Prefs
import com.microclicker.data.Samples
import com.microclicker.data.TemplateStore
import org.opencv.android.OpenCVLoader
import java.io.File

/** Tiny service locator. Initialised once in [com.microclicker.App]. */
object Graph {
    lateinit var app: Application
        private set
    lateinit var macros: MacroRepository
        private set
    lateinit var templates: TemplateStore
        private set
    lateinit var prefs: Prefs
        private set

    @Volatile
    var openCvReady: Boolean = false
        private set

    fun init(application: Application) {
        app = application
        macros = MacroRepository(File(application.filesDir, "macros"))
        templates = TemplateStore(File(application.filesDir, "templates"))
        prefs = Prefs(application)
        openCvReady = runCatching { OpenCVLoader.initLocal() }.getOrDefault(false)
        Samples.seedIfNeeded()
    }
}
