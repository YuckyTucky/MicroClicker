package com.microclicker.core

import android.graphics.Bitmap

enum class GlobalKey { BACK, HOME, RECENTS, NOTIFICATIONS, QUICK_SETTINGS, LOCK_SCREEN }

/** A found photo, in real screen pixels (centre point + size). */
data class Match(
    val cx: Float,
    val cy: Float,
    val w: Float,
    val h: Float,
    val score: Double,
)

/**
 * Everything the engine needs from the phone. The accessibility service implements this;
 * the engine never touches Android services directly, so it can be tested or swapped.
 */
interface Device {
    val screenWidth: Int
    val screenHeight: Int

    suspend fun tap(x: Float, y: Float, holdMs: Long): Boolean

    /** [bend] pushes the middle of the path sideways by that many px (0 = straight). */
    suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long, bend: Float): Boolean

    /** Several fingers down at once. */
    suspend fun multiTouch(points: List<Pair<Float, Float>>, holdMs: Long): Boolean

    suspend fun screenshot(): Bitmap?

    fun global(key: GlobalKey): Boolean
    fun openUrl(url: String, pkg: String?): Boolean
    fun openApp(pkg: String): Boolean

    /** Package of the app currently in front, if known. */
    fun foregroundPackage(): String?

    /** Text of the browser address bar, if one is visible and readable. */
    fun currentUrl(): String?
}
