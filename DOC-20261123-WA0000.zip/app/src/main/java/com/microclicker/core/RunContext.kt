package com.microclicker.core

import android.os.SystemClock

/** Everything an action or condition can use while a macro runs. One per run. */
class RunContext(
    val device: Device,
    val macro: Macro,
    val vision: Vision,
    val hum: Humanizer,
    val guard: GuardMonitor,
    val runner: MacroRunner,
    private val logFn: (String) -> Unit,
) {
    /** 1-based number of the cycle currently running. */
    var cycle: Int = 0

    private val startedAt: Long = SystemClock.elapsedRealtime()
    val elapsedSec: Long get() = (SystemClock.elapsedRealtime() - startedAt) / 1000

    /** How many times each step (by id) has actually run. */
    val stepRuns = HashMap<String, Int>()

    /** Set by the photo step right before it runs its "then" action. */
    var lastMatch: Match? = null

    /** Nesting depth of run_macro calls (guards against endless recursion). */
    var depth: Int = 0

    fun log(msg: String) = logFn(msg)

    /** Runs the action stored under [key] (e.g. "then") inside [p]. */
    suspend fun runNested(p: Params, key: String): StepResult {
        val type = p.str(key)
        val action = Actions.get(type) ?: return StepResult.DONE
        val sub = p.sub("$key.", action.defaults)
        return action.run(this, Step(type = type, params = sub.obj), sub)
    }
}
