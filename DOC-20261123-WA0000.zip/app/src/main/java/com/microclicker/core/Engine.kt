package com.microclicker.core

import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class RunState(
    val running: Boolean = false,
    val macroId: String = "",
    val macroName: String = "",
    val cycle: Int = 0,
    val step: String = "",
)

/**
 * The one place that starts and stops macros. The accessibility service plugs itself in
 * via [attach]; the app UI and the floating bubble both talk to this object.
 */
object Engine {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    @Volatile
    private var device: Device? = null

    @Volatile
    private var runCounter = 0L

    val state = MutableStateFlow(RunState())
    val logLines = MutableStateFlow<List<String>>(emptyList())

    /** True while the accessibility service is connected. */
    val serviceReady = MutableStateFlow(false)

    fun attach(d: Device) {
        device = d
        serviceReady.value = true
    }

    fun detach(d: Device) {
        if (device === d) {
            stop()
            device = null
            serviceReady.value = false
        }
    }

    @Synchronized
    fun start(macroId: String): Boolean {
        val d = device
        if (d == null) {
            log("Turn on the Micro Clicker accessibility service first.")
            return false
        }
        val macro = Graph.macros.get(macroId)
        if (macro == null) {
            log("Macro not found.")
            return false
        }
        stop()

        val myRun = ++runCounter
        val runner = MacroRunner(d, { msg -> log(msg) }) { cycle, step ->
            state.update { it.copy(cycle = cycle, step = step) }
        }
        state.value = RunState(running = true, macroId = macro.id, macroName = macro.name)
        log("▶ Started \"${macro.name}\"")

        job = scope.launch {
            try {
                runner.run(macro)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                log("⚠ ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                // Only react if this run ended by itself (stop() bumps runCounter first).
                if (runCounter == myRun) {
                    state.value = RunState()
                    log("■ Done")
                }
            }
        }
        return true
    }

    @Synchronized
    fun stop() {
        val j = job ?: return
        if (j.isActive) {
            runCounter++
            j.cancel()
            state.value = RunState()
            log("■ Stopped")
        }
        job = null
    }

    /** Start after a short pause, so you can switch to the app you want to click in. */
    fun startAfter(macroId: String, delayMs: Long) {
        scope.launch {
            delay(delayMs)
            start(macroId)
        }
    }

    /** Start the selected macro, or stop whatever is running. Used by the floating bubble. */
    fun toggleSelected() {
        if (state.value.running) {
            stop()
        } else {
            val id = Graph.prefs.selectedMacroId.value
            if (id.isNotEmpty()) start(id) else log("Pick a macro in the app first.")
        }
    }

    fun log(msg: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        logLines.update { (it + "$time  $msg").takeLast(80) }
        Log.i("MicroClicker", msg)
    }

    fun clearLog() {
        logLines.value = emptyList()
    }
}
