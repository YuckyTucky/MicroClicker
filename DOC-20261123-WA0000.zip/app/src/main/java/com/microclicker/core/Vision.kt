package com.microclicker.core

import android.graphics.BitmapFactory
import android.os.SystemClock
import kotlinx.coroutines.delay
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.max
import kotlin.math.min

/** An OpenCV image plus a lazily-made half-size copy (matching at half size is ~4x faster). */
class Img(val full: Mat) {
    private var halfMat: Mat? = null

    val half: Mat
        get() = halfMat ?: Mat().also {
            Imgproc.resize(full, it, Size(), 0.5, 0.5, Imgproc.INTER_AREA)
            halfMat = it
        }

    fun release() {
        full.release()
        halfMat?.release()
        halfMat = null
    }
}

data class FindResult(
    /** Every copy of the photo that scored >= threshold, best first. */
    val matches: List<Match>,
    /** Best score seen, even if below threshold (useful for tuning). */
    val best: Double,
)

/**
 * Looks at the screen and finds saved photos in it (template matching).
 * One instance per macro run; call [close] when done.
 */
class Vision(private val device: Device) {

    private var last: Img? = null
    private var lastAt = 0L
    private var lastRealShot = 0L
    private val templates = HashMap<String, Pair<Long, Img>>()

    /**
     * A screenshot as an OpenCV image. If [maxAgeMs] > 0 and a newer-than-that frame exists, reuses it.
     * Android refuses screenshots closer than ~330 ms apart, so we space them out ourselves.
     */
    suspend fun frame(maxAgeMs: Long = 0): Img? {
        val now = SystemClock.elapsedRealtime()
        last?.let { if (maxAgeMs > 0 && now - lastAt <= maxAgeMs) return it }

        val wait = MIN_SHOT_GAP_MS - (now - lastRealShot)
        if (wait > 0) delay(wait)
        lastRealShot = SystemClock.elapsedRealtime()

        val bmp = device.screenshot() ?: return null
        val rgba = Mat()
        Utils.bitmapToMat(bmp, rgba)
        bmp.recycle()
        val rgb = Mat()
        Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
        rgba.release()

        last?.release()
        val img = Img(rgb)
        last = img
        lastAt = SystemClock.elapsedRealtime()
        return img
    }

    private fun template(id: String): Img? {
        val file = Graph.templates.file(id)
        if (!file.exists()) return null
        val stamp = file.lastModified()
        templates[id]?.let {
            if (it.first == stamp) return it.second
            it.second.release()
        }
        val bmp = BitmapFactory.decodeFile(file.absolutePath) ?: return null
        val rgba = Mat()
        Utils.bitmapToMat(bmp, rgba)
        bmp.recycle()
        val rgb = Mat()
        Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
        rgba.release()
        val img = Img(rgb)
        templates[id] = stamp to img
        return img
    }

    /**
     * Find saved photo [templateId] on screen. Returns null if the screenshot or the photo
     * could not be loaded. [area] is one of full | top | bottom | left | right (the whole
     * photo must fit inside that part of the screen).
     */
    suspend fun find(
        templateId: String,
        threshold: Double,
        area: String = "full",
        maxMatches: Int = 8,
        maxAgeMs: Long = 0,
    ): FindResult? {
        val tpl = template(templateId) ?: return null
        val frame = frame(maxAgeMs) ?: return null
        return match(frame, tpl, threshold, area, maxMatches)
    }

    private fun match(frame: Img, tpl: Img, threshold: Double, area: String, maxMatches: Int): FindResult {
        val useHalf = min(tpl.full.cols(), tpl.full.rows()) >= 48
        val scale = if (useHalf) 0.5 else 1.0
        val src = if (useHalf) frame.half else frame.full
        val t = if (useHalf) tpl.half else tpl.full

        val roi = areaRect(src.cols(), src.rows(), area)
        if (roi.width < t.cols() || roi.height < t.rows()) return FindResult(emptyList(), 0.0)

        val sub = src.submat(roi)
        val res = Mat()
        Imgproc.matchTemplate(sub, t, res, Imgproc.TM_CCOEFF_NORMED)
        Core.patchNaNs(res, 0.0) // flat-colour photos produce NaN

        val out = ArrayList<Match>()
        var best = 0.0
        for (i in 0 until maxMatches) {
            val mm = Core.minMaxLoc(res)
            if (i == 0) best = mm.maxVal
            if (mm.maxVal < threshold) break

            val px = mm.maxLoc.x
            val py = mm.maxLoc.y
            out += Match(
                cx = ((roi.x + px + t.cols() / 2.0) / scale).toFloat(),
                cy = ((roi.y + py + t.rows() / 2.0) / scale).toFloat(),
                w = (t.cols() / scale).toFloat(),
                h = (t.rows() / scale).toFloat(),
                score = mm.maxVal,
            )
            // Blank out this neighbourhood so the next pass finds a different copy.
            val x0 = max(0.0, px - t.cols() / 2.0)
            val y0 = max(0.0, py - t.rows() / 2.0)
            val x1 = min(res.cols() - 1.0, px + t.cols() / 2.0)
            val y1 = min(res.rows() - 1.0, py + t.rows() / 2.0)
            Imgproc.rectangle(res, Point(x0, y0), Point(x1, y1), Scalar(0.0), -1)
        }
        res.release()
        sub.release()
        return FindResult(out, best)
    }

    private fun areaRect(w: Int, h: Int, area: String): Rect = when (area) {
        "top" -> Rect(0, 0, w, h / 2)
        "bottom" -> Rect(0, h / 2, w, h - h / 2)
        "left" -> Rect(0, 0, w / 2, h)
        "right" -> Rect(w / 2, 0, w - w / 2, h)
        else -> Rect(0, 0, w, h)
    }

    fun close() {
        last?.release()
        last = null
        templates.values.forEach { it.second.release() }
        templates.clear()
    }

    private companion object {
        const val MIN_SHOT_GAP_MS = 380L
    }
}
