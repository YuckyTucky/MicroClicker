package com.microclicker.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import com.microclicker.conditions.Conditions

/**
 * Runs a macro: cycle after cycle, step after step. Suspending, so cancelling the coroutine
 * (the Stop button) stops it instantly, even in the middle of a wait.
 */
class MacroRunner(
    private val device: Device,
    private val log: (String) -> Unit,
    private val onProgress: (cycle: Int, step: String) -> Unit,
) {
    suspend fun run(macro: Macro) {
        val vision = Vision(device)
        val hum = Humanizer(macro.humanize)
        val guard = GuardMonitor(device, macro.guard, Graph.app.packageName, log)
        val ctx = RunContext(device, macro, vision, hum, guard, this, log)
        try {
            while (currentCoroutineContext().isActive) {
                ctx.cycle++
                onProgress(ctx.cycle, "")

                if (guard.active && guard.checkAndRecover(settle = false) == GuardOutcome.STOP) break

                if (runSteps(ctx, macro.steps) == StepResult.STOP) break

                val loop = macro.loop
                if (loop.cycles > 0 && ctx.cycle >= loop.cycles) {
                    log("✔ Finished ${loop.cycles} cycle(s)")
                    break
                }
                if (loop.maxRuntimeSec > 0 && ctx.elapsedSec >= loop.maxRuntimeSec) {
                    log("⏱ Max runtime reached")
                    break
                }
                delay(hum.delay(loop.gap).coerceAtLeast(20L))
            }
        } finally {
            vision.close()
        }
    }

    /** Runs [steps] once. Also used by the run_macro action. */
    suspend fun runSteps(ctx: RunContext, steps: List<Step>): StepResult {
        for (step in steps) {
            when (runStep(ctx, step)) {
                StepResult.STOP -> return StepResult.STOP
                StepResult.RESTART_CYCLE -> return StepResult.RESTART_CYCLE
                else -> Unit
            }
        }
        return StepResult.DONE
    }

    private suspend fun runStep(ctx: RunContext, step: Step): StepResult {
        currentCoroutineContext().ensureActive()
        if (!step.enabled) return StepResult.SKIPPED

        val maxSec = ctx.macro.loop.maxRuntimeSec
        if (maxSec > 0 && ctx.elapsedSec >= maxSec) {
            ctx.log("⏱ Max runtime reached")
            return StepResult.STOP
        }

        val action = Actions.get(step.type)
        if (action == null) {
            ctx.log("Unknown action \"${step.type}\" – skipped")
            return StepResult.SKIPPED
        }

        // Conditions: every one must pass.
        for (c in step.conditions) {
            val cond = Conditions.get(c.type) ?: continue
            if (!cond.eval(ctx, c)) return StepResult.SKIPPED
        }

        val label = step.name.ifBlank { action.label }
        onProgress(ctx.cycle, label)

        val before = ctx.hum.delay(step.timing.before)
        if (before > 0) delay(before)

        val p = Params(step.params, action.defaults)
        val result = try {
            action.run(ctx, step, p)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            ctx.log("⚠ $label failed: ${e.message ?: e.javaClass.simpleName}")
            StepResult.SKIPPED
        }

        if (result == StepResult.SKIPPED) return result
        ctx.stepRuns[step.id] = (ctx.stepRuns[step.id] ?: 0) + 1
        if (result == StepResult.STOP || result == StepResult.RESTART_CYCLE) return result

        if (action.mayNavigate && ctx.guard.active) {
            if (ctx.guard.checkAndRecover() == GuardOutcome.STOP) return StepResult.STOP
        }

        val after = ctx.hum.delay(step.timing.after)
        if (after > 0) delay(after)

        val pause = ctx.hum.randomPauseMs()
        if (pause > 0) {
            ctx.log("☕ Random pause ${pause / 1000}s")
            delay(pause)
        }
        return result
    }
}
