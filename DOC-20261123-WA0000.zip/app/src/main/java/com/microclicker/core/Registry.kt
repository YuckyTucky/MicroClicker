package com.microclicker.core

import com.microclicker.actions.ImageAction
import com.microclicker.actions.MultiTapAction
import com.microclicker.actions.NoopAction
import com.microclicker.actions.OpenAppAction
import com.microclicker.actions.OpenLinkAction
import com.microclicker.actions.RunMacroAction
import com.microclicker.actions.StopAction
import com.microclicker.actions.SwipeAction
import com.microclicker.actions.SystemKeyAction
import com.microclicker.actions.TapAction
import com.microclicker.actions.TapMatchAction
import com.microclicker.actions.WaitAction

/** How the editor renders a field. */
enum class Kind {
    INT, DECIMAL, TEXT, BOOL, CHOICE,
    TEMPLATE,      // pick a saved photo
    APP,           // pick an installed app (stores the package name)
    MACRO,         // pick another macro
    POINTS,        // text "x,y;x,y" with a "pick on screen" button
    PICK_TAP,      // button only: pick a point on screen -> writes x, y
    PICK_SWIPE,    // button only: drag on screen -> writes x, y, x2, y2, duration
    NESTED,        // pick another action and edit its fields in place (stored with "<key>." prefix)
}

/**
 * One editable setting of an action. The editor UI is generated from these,
 * so a new action never needs UI code.
 */
data class Field(
    val key: String,
    val label: String,
    val kind: Kind,
    val default: String = "",
    val options: List<Pair<String, String>> = emptyList(), // value -> label (CHOICE)
    val help: String = "",
    val unit: String = "",
    val showIf: ((Params) -> Boolean)? = null,
)

enum class Scope { BOTH, TOP_ONLY, NESTED_ONLY }

enum class StepResult { DONE, SKIPPED, STOP, RESTART_CYCLE }

/**
 * ===== HOW TO ADD A NEW ACTION =====
 * 1. Create an object implementing [Action] (see actions/FlowActions.kt for tiny examples).
 * 2. Describe its settings in [fields]; implement [run].
 * 3. Add it to the list in [Actions] below. Done: it shows up in the editor automatically.
 */
interface Action {
    val type: String
    val label: String
    val description: String
    val icon: String get() = "•"
    val scope: Scope get() = Scope.BOTH

    /** If true, the Guard checks where we ended up after this action runs. */
    val mayNavigate: Boolean get() = false

    val fields: List<Field>

    suspend fun run(ctx: RunContext, step: Step, p: Params): StepResult

    /** Short text for the step list, e.g. "(540, 1200) ×3". */
    fun summary(p: Params): String = ""
}

/** Default values of this action's fields (button-only fields start with "_"). */
val Action.defaults: Map<String, String>
    get() = fields.filter { !it.key.startsWith("_") && it.default.isNotEmpty() }
        .associate { it.key to it.default }

object Actions {
    private val all = LinkedHashMap<String, Action>()

    private fun register(a: Action) {
        all[a.type] = a
    }

    init {
        // Order here = order in the "add step" list.
        register(ImageAction)
        register(TapAction)
        register(MultiTapAction)
        register(SwipeAction)
        register(OpenLinkAction)
        register(OpenAppAction)
        register(SystemKeyAction)
        register(WaitAction)
        register(RunMacroAction)
        register(StopAction)
        // Only usable inside "when photo is found":
        register(TapMatchAction)
        register(NoopAction)
    }

    fun get(type: String): Action? = all[type]
    fun topLevel(): List<Action> = all.values.filter { it.scope != Scope.NESTED_ONLY }
    fun nestable(): List<Action> = all.values.filter { it.scope != Scope.TOP_ONLY }
}
