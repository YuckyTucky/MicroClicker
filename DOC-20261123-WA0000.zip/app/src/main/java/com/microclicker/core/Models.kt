package com.microclicker.core

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import java.util.UUID

/** One shared Json config. Lenient on input, verbose on output so exported macros are easy to hand-edit. */
val AppJson = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
    prettyPrint = true
    isLenient = true
    coerceInputValues = true
}

object Ids {
    fun new(): String = UUID.randomUUID().toString().replace("-", "").take(8)
}

/** A delay in ms. If maxMs > minMs the actual delay is random in [minMs, maxMs]. */
@Serializable
data class Delay(val minMs: Long = 0, val maxMs: Long = 0)

@Serializable
data class Timing(
    val before: Delay = Delay(0, 0),
    val after: Delay = Delay(500, 500),
)

/**
 * A rule that must be true for a step to run. `type` is looked up in [Conditions].
 * value / value2 meaning depends on the type (see conditions/Conditions.kt).
 */
@Serializable
data class Condition(
    val type: String,
    val value: String = "",
    val value2: String = "",
)

/**
 * One unit of a macro. `type` is looked up in [Actions]; `params` holds that action's settings
 * (keys are defined by the action's field list), so new actions never need a model change.
 */
@Serializable
data class Step(
    val id: String = Ids.new(),
    val type: String,
    val name: String = "",
    val enabled: Boolean = true,
    val params: JsonObject = JsonObject(emptyMap()),
    val timing: Timing = Timing(),
    val conditions: List<Condition> = emptyList(),
)

@Serializable
data class LoopSettings(
    /** 0 = repeat forever */
    val cycles: Int = 0,
    val gap: Delay = Delay(500, 500),
    /** 0 = no limit */
    val maxRuntimeSec: Int = 0,
)

/** "Look like a person" settings, used against AFK / bot detection. */
@Serializable
data class Humanize(
    val enabled: Boolean = false,
    /** Every delay is nudged by up to ±this percent. */
    val timingJitterPct: Int = 20,
    /** Every tap lands up to this many pixels away from the target. */
    val positionJitterPx: Int = 8,
    /** Press duration varies by up to ±this percent. */
    val holdJitterPct: Int = 30,
    /** Chance (per step) of a long random pause. */
    val pauseChancePct: Int = 2,
    val pauseMinSec: Int = 5,
    val pauseMaxSec: Int = 25,
    /** Swipes follow a slightly curved path instead of a ruler-straight line. */
    val swipeCurve: Boolean = true,
)

object HumanizePresets {
    val OFF = Humanize(enabled = false)
    val LIGHT = Humanize(true, 10, 4, 15, 0, 5, 15, true)
    val STRONG = Humanize(true, 30, 12, 40, 4, 8, 45, true)
}

/** Keeps a macro from wandering into places you don't want it to go. */
@Serializable
data class Guard(
    val enabled: Boolean = false,
    /** Package names that must never be in front (e.g. com.android.chrome). */
    val blockedPackages: List<String> = emptyList(),
    /** If the browser's address bar contains any of these words, it's a violation. */
    val blockedUrlWords: List<String> = emptyList(),
    /** If set, any other app coming to the front is a violation. */
    val onlyPackage: String = "",
    /** back | open_app | open_url | stop */
    val recovery: String = "back",
    /** Package name (open_app) or URL (open_url) */
    val recoveryTarget: String = "",
    /** How long to wait after an action before checking where we ended up. */
    val settleMs: Long = 800,
)

@Serializable
data class Macro(
    val id: String = Ids.new(),
    val name: String = "New macro",
    val steps: List<Step> = emptyList(),
    val loop: LoopSettings = LoopSettings(),
    val humanize: Humanize = Humanize(),
    val guard: Guard = Guard(),
    val schema: Int = 1,
)
