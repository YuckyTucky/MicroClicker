package com.microclicker.core

import kotlinx.coroutines.delay

enum class GuardOutcome { CLEAR, RECOVERED, STOP }

/**
 * Watches where the phone ends up after an action. If the macro got thrown into a blocked app,
 * a blocked website, or just out of the app it should stay in, it recovers (back / open app /
 * open link) or stops the macro.
 *
 * Reading the website needs a browser that shows its address bar to accessibility
 * (Chrome, Samsung Internet, Firefox, Edge, Brave and Opera do). For anything else, block by app.
 */
class GuardMonitor(
    private val device: Device,
    private val cfg: Guard,
    private val ownPackage: String,
    private val log: (String) -> Unit,
) {
    val active: Boolean
        get() = cfg.enabled &&
            (cfg.blockedPackages.isNotEmpty() || cfg.blockedUrlWords.isNotEmpty() || cfg.onlyPackage.isNotBlank())

    /** Describes what's wrong right now, or null if all is fine. */
    fun violation(): String? {
        val pkg = device.foregroundPackage() ?: return null
        if (isIgnorable(pkg)) return null

        if (cfg.blockedPackages.any { it.isNotBlank() && it.trim() == pkg }) return "blocked app $pkg"
        if (cfg.onlyPackage.isNotBlank() && pkg != cfg.onlyPackage.trim()) {
            return "left ${cfg.onlyPackage} (now in $pkg)"
        }
        if (cfg.blockedUrlWords.isNotEmpty()) {
            val url = device.currentUrl()?.lowercase()
            if (url != null) {
                val hit = cfg.blockedUrlWords.firstOrNull { w -> w.isNotBlank() && url.contains(w.trim().lowercase()) }
                if (hit != null) return "blocked site \"$hit\" ($url)"
            }
        }
        return null
    }

    private fun isIgnorable(pkg: String): Boolean =
        pkg == ownPackage ||
            pkg == "android" ||
            pkg.startsWith("com.android.systemui") ||
            pkg.contains("inputmethod") ||
            pkg.contains("keyboard")

    /**
     * Checks for a violation and fixes it. [settle] waits first so the new screen has time to load.
     * Returns STOP if the macro should end (recovery = stop, or recovery failed three times).
     */
    suspend fun checkAndRecover(settle: Boolean = true): GuardOutcome {
        if (!active) return GuardOutcome.CLEAR
        if (settle) delay(cfg.settleMs.coerceIn(0L, 10_000L))

        var v = violation() ?: return GuardOutcome.CLEAR
        for (attempt in 1..3) {
            log("🛡 Guard: $v → ${cfg.recovery} (try $attempt)")
            when (cfg.recovery) {
                "stop" -> return GuardOutcome.STOP
                "open_app" ->
                    if (cfg.recoveryTarget.isBlank()) device.global(GlobalKey.BACK)
                    else device.openApp(cfg.recoveryTarget.trim())
                "open_url" ->
                    if (cfg.recoveryTarget.isBlank()) device.global(GlobalKey.BACK)
                    else device.openUrl(cfg.recoveryTarget.trim(), null)
                else -> device.global(GlobalKey.BACK)
            }
            delay(900)
            v = violation() ?: return GuardOutcome.RECOVERED
        }
        log("🛡 Guard: couldn't get back after 3 tries, stopping the macro to be safe")
        return GuardOutcome.STOP
    }
}
