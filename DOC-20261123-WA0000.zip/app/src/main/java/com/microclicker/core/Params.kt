package com.microclicker.core

import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * Typed, forgiving view over a step's params JSON.
 * Falls back to [defaults] (taken from the action's field list) so there is exactly one
 * place where a default value is defined: the Field.
 */
class Params(
    val obj: JsonObject = JsonObject(emptyMap()),
    private val defaults: Map<String, String> = emptyMap(),
) {
    /** Stored value if the user set a non-blank one, otherwise the field default. */
    private fun raw(k: String): String? {
        val el = obj[k]
        if (el is JsonPrimitive && el !is JsonNull && el.content.isNotBlank()) return el.content
        return defaults[k]
    }

    /** Exactly what is stored (may be blank), or null if nothing is stored. For editor text boxes. */
    fun stored(k: String): String? {
        val el = obj[k]
        return if (el is JsonPrimitive && el !is JsonNull) el.content else null
    }

    /** True if the user explicitly stored a value for [k]. */
    fun has(k: String): Boolean {
        val el = obj[k]
        return el is JsonPrimitive && el !is JsonNull
    }

    fun str(k: String, d: String = ""): String = raw(k) ?: d

    fun int(k: String, d: Int = 0): Int {
        val s = raw(k)?.trim() ?: return d
        return s.toIntOrNull() ?: s.toDoubleOrNull()?.toInt() ?: d
    }

    fun long(k: String, d: Long = 0L): Long {
        val s = raw(k)?.trim() ?: return d
        return s.toLongOrNull() ?: s.toDoubleOrNull()?.toLong() ?: d
    }

    fun double(k: String, d: Double = 0.0): Double =
        raw(k)?.trim()?.replace(',', '.')?.toDoubleOrNull() ?: d

    fun bool(k: String, d: Boolean = false): Boolean {
        val s = raw(k)?.trim()?.lowercase() ?: return d
        return s == "true" || s == "1" || s == "yes"
    }

    /** "x,y;x,y;..." -> list of points. Ignores anything it can't parse. */
    fun points(k: String): List<Pair<Float, Float>> =
        str(k).split(';', '\n').mapNotNull { part ->
            val xy = part.split(',').map { it.trim() }
            val x = xy.getOrNull(0)?.toFloatOrNull()
            val y = xy.getOrNull(1)?.toFloatOrNull()
            if (x != null && y != null) x to y else null
        }

    /** Returns a copy with [k] set (null removes it). */
    fun set(k: String, v: Any?): Params {
        val m = LinkedHashMap<String, JsonElement>(obj)
        when (v) {
            null -> m.remove(k)
            is Boolean -> m[k] = JsonPrimitive(v)
            is Int -> m[k] = JsonPrimitive(v)
            is Long -> m[k] = JsonPrimitive(v)
            is Double -> m[k] = JsonPrimitive(v)
            is Float -> m[k] = JsonPrimitive(v)
            else -> m[k] = JsonPrimitive(v.toString())
        }
        return Params(JsonObject(m), defaults)
    }

    /** Params whose keys start with [prefix], with the prefix stripped. Used for nested actions. */
    fun sub(prefix: String, subDefaults: Map<String, String> = emptyMap()): Params =
        Params(
            JsonObject(
                obj.filterKeys { it.startsWith(prefix) }
                    .mapKeys { it.key.removePrefix(prefix) }
            ),
            subDefaults,
        )

    fun withDefaults(d: Map<String, String>): Params = Params(obj, d)
}
