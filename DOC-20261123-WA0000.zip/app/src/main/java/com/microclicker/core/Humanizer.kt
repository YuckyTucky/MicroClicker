package com.microclicker.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * All randomness lives here, so "make it look human" is one class to tune.
 * A step's explicit random range (Delay.minMs..maxMs) always applies;
 * the extra jitter below only applies when Humanize.enabled is on.
 */
class Humanizer(private val cfg: Humanize, private val rnd: Random = Random.Default) {

    val random: Random get() = rnd

    /** Triangular noise in (-1, 1): small nudges are likelier than big ones. */
    private fun tri(): Double = rnd.nextDouble() - rnd.nextDouble()

    fun delay(d: Delay): Long {
        var v = if (d.maxMs > d.minMs) rnd.nextLong(d.minMs, d.maxMs + 1) else d.minMs
        if (cfg.enabled && cfg.timingJitterPct > 0 && v > 0) {
            v += (v * cfg.timingJitterPct / 100.0 * tri()).toLong()
        }
        return max(0L, v)
    }

    /** Press duration for a tap. */
    fun hold(ms: Long): Long {
        var v = ms.coerceAtLeast(1L)
        if (cfg.enabled && cfg.holdJitterPct > 0) {
            v += (v * cfg.holdJitterPct / 100.0 * tri()).toLong()
        }
        return max(20L, v)
    }

    /** Move a point a few pixels, staying on screen. */
    fun point(x: Float, y: Float, screenW: Int, screenH: Int): Pair<Float, Float> {
        val r = cfg.positionJitterPx
        if (!cfg.enabled || r <= 0) return x to y
        val angle = rnd.nextDouble() * 2 * PI
        val dist = r * sqrt(rnd.nextDouble())
        val nx = (x + (cos(angle) * dist).toFloat()).coerceIn(0f, (screenW - 1).coerceAtLeast(1).toFloat())
        val ny = (y + (sin(angle) * dist).toFloat()).coerceIn(0f, (screenH - 1).coerceAtLeast(1).toFloat())
        return nx to ny
    }

    /** Sideways bend (px) for a swipe of the given length. 0 = straight line. */
    fun swipeBend(distance: Float): Float =
        if (cfg.enabled && cfg.swipeCurve) (tri() * distance * 0.10).toFloat() else 0f

    /** 0 most of the time; occasionally a long "went to get coffee" pause. */
    fun randomPauseMs(): Long {
        if (!cfg.enabled || cfg.pauseChancePct <= 0) return 0L
        if (rnd.nextInt(100) >= cfg.pauseChancePct) return 0L
        val lo = cfg.pauseMinSec.coerceAtLeast(1)
        val hi = max(cfg.pauseMaxSec, lo)
        return rnd.nextLong(lo * 1000L, hi * 1000L + 1)
    }

    /** True with probability pct/100. */
    fun chance(pct: Int): Boolean = rnd.nextInt(100) < pct.coerceIn(0, 100)
}
