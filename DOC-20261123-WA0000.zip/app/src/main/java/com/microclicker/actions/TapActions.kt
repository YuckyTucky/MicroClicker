package com.microclicker.actions

import com.microclicker.core.Action
import com.microclicker.core.Delay
import com.microclicker.core.Field
import com.microclicker.core.Kind
import com.microclicker.core.Params
import com.microclicker.core.RunContext
import com.microclicker.core.Scope
import com.microclicker.core.Step
import com.microclicker.core.StepResult
import kotlinx.coroutines.delay

/** Taps [count] times at (x, y) with a (possibly random) pause between taps. */
internal suspend fun doTaps(ctx: RunContext, x: Float, y: Float, count: Int, gap: Delay, holdMs: Long): Boolean {
    var ok = true
    val n = count.coerceAtLeast(1)
    for (i in 0 until n) {
        val (px, py) = ctx.hum.point(x, y, ctx.device.screenWidth, ctx.device.screenHeight)
        ok = ctx.device.tap(px, py, ctx.hum.hold(holdMs)) && ok
        if (i < n - 1) delay(ctx.hum.delay(gap).coerceAtLeast(10L))
    }
    return ok
}

internal fun gapOf(p: Params): Delay = Delay(p.long("gapMin"), p.long("gapMax"))

/** The two "pause between repeats" fields, shared by several actions. */
internal fun gapFields(default: String, showIf: ((Params) -> Boolean)?): List<Field> = listOf(
    Field("gapMin", "Pause between repeats: min", Kind.INT, default, unit = "ms", showIf = showIf),
    Field(
        "gapMax", "Pause between repeats: max", Kind.INT, default, unit = "ms",
        help = "Make max bigger than min and the pause is random every time.",
        showIf = showIf,
    ),
)

object TapAction : Action {
    override val type = "tap"
    override val label = "Tap"
    override val description = "Tap one spot on the screen, once or many times (multi-click)."
    override val icon = "👆"
    override val mayNavigate = true

    override val fields: List<Field> = listOf(
        Field("_pick", "Pick the spot on screen", Kind.PICK_TAP),
        Field("x", "X", Kind.INT, "540", unit = "px"),
        Field("y", "Y", Kind.INT, "1200", unit = "px"),
        Field("count", "Number of taps", Kind.INT, "1", help = "Above 1 = multi-click: taps this many times in a row."),
    ) + gapFields("80") { it.int("count") > 1 } + listOf(
        Field("hold", "Press time", Kind.INT, "40", unit = "ms"),
    )

    override suspend fun run(ctx: RunContext, step: Step, p: Params): StepResult {
        val ok = doTaps(ctx, p.int("x").toFloat(), p.int("y").toFloat(), p.int("count"), gapOf(p), p.long("hold"))
        if (!ok) ctx.log("Android did not accept the tap")
        return StepResult.DONE
    }

    override fun summary(p: Params): String {
        val n = p.int("count")
        return "(${p.int("x")}, ${p.int("y")})" + if (n > 1) " ×$n" else ""
    }
}

object MultiTapAction : Action {
    override val type = "multi_tap"
    override val label = "Multi-tap (several spots)"
    override val description = "Tap a list of spots: one after another, or all at the same time (several fingers)."
    override val icon = "🖐"
    override val mayNavigate = true

    override val fields: List<Field> = listOf(
        Field(
            "points", "Spots", Kind.POINTS, "",
            help = "Format: x,y;x,y;x,y. Use the button to add spots from the screen.",
        ),
        Field(
            "mode", "How", Kind.CHOICE, "sequence",
            options = listOf("sequence" to "One after another", "together" to "All at the same time"),
        ),
    ) + gapFields("150") { it.str("mode") == "sequence" } + listOf(
        Field("hold", "Press time", Kind.INT, "40", unit = "ms"),
        Field("rounds", "Repeat the whole set", Kind.INT, "1", unit = "times"),
    )

    override suspend fun run(ctx: RunContext, step: Step, p: Params): StepResult {
        val pts = p.points("points")
        if (pts.isEmpty()) {
            ctx.log("Multi-tap: no spots set")
            return StepResult.SKIPPED
        }
        val w = ctx.device.screenWidth
        val h = ctx.device.screenHeight
        val together = p.str("mode") == "together"
        val rounds = p.int("rounds").coerceAtLeast(1)

        for (r in 0 until rounds) {
            if (together) {
                val moved = pts.map { (x, y) -> ctx.hum.point(x, y, w, h) }
                ctx.device.multiTouch(moved, ctx.hum.hold(p.long("hold")))
            } else {
                for ((i, pt) in pts.withIndex()) {
                    val (x, y) = ctx.hum.point(pt.first, pt.second, w, h)
                    ctx.device.tap(x, y, ctx.hum.hold(p.long("hold")))
                    if (i < pts.lastIndex) delay(ctx.hum.delay(gapOf(p)).coerceAtLeast(10L))
                }
            }
            if (r < rounds - 1) delay(ctx.hum.delay(gapOf(p)).coerceAtLeast(10L))
        }
        return StepResult.DONE
    }

    override fun summary(p: Params): String {
        val n = p.points("points").size
        return "$n spot(s), " + if (p.str("mode") == "together") "together" else "in order"
    }
}

/** Only meaningful inside a photo step's "when found": taps the spot where the photo was seen. */
object TapMatchAction : Action {
    override val type = "tap_match"
    override val label = "Tap the photo"
    override val description = "Tap the spot where the photo was found."
    override val icon = "🎯"
    override val scope = Scope.NESTED_ONLY
    override val mayNavigate = true

    override val fields: List<Field> = listOf(
        Field("offsetX", "Shift right", Kind.INT, "0", unit = "px", help = "Negative = left."),
        Field("offsetY", "Shift down", Kind.INT, "0", unit = "px", help = "Negative = up."),
        Field(
            "randomInside", "Tap a random spot inside the photo", Kind.BOOL, "false",
            help = "Looks less robotic than always hitting the exact centre.",
        ),
        Field("count", "Number of taps", Kind.INT, "1"),
    ) + gapFields("80") { it.int("count") > 1 } + listOf(
        Field("hold", "Press time", Kind.INT, "40", unit = "ms"),
    )

    override suspend fun run(ctx: RunContext, step: Step, p: Params): StepResult {
        val m = ctx.lastMatch
        if (m == null) {
            ctx.log("Tap the photo: nothing was found yet")
            return StepResult.SKIPPED
        }
        var x = m.cx + p.int("offsetX")
        var y = m.cy + p.int("offsetY")
        if (p.bool("randomInside")) {
            x += ((ctx.hum.random.nextDouble() - 0.5) * m.w * 0.6).toFloat()
            y += ((ctx.hum.random.nextDouble() - 0.5) * m.h * 0.6).toFloat()
        }
        doTaps(ctx, x, y, p.int("count"), gapOf(p), p.long("hold"))
        return StepResult.DONE
    }

    override fun summary(p: Params): String = "tap it"
}
