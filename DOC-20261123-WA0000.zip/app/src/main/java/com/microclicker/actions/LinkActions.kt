package com.microclicker.actions

import com.microclicker.core.Action
import com.microclicker.core.Field
import com.microclicker.core.Kind
import com.microclicker.core.Params
import com.microclicker.core.RunContext
import com.microclicker.core.Step
import com.microclicker.core.StepResult

/** The "link micro" / website micro. */
object OpenLinkAction : Action {
    override val type = "open_link"
    override val label = "Open website / link"
    override val description = "Open a web address (or any link, like a deep link into an app)."
    override val icon = "🔗"

    override val fields: List<Field> = listOf(
        Field("url", "Link", Kind.TEXT, "https://", help = "https://… or an app link such as market://… "),
        Field(
            "package", "Open with (optional)", Kind.APP, "",
            help = "Leave empty to use the default browser or app.",
        ),
    )

    override suspend fun run(ctx: RunContext, step: Step, p: Params): StepResult {
        val raw = p.str("url").trim()
        if (raw.isEmpty() || raw == "https://") {
            ctx.log("Open link: no link set")
            return StepResult.SKIPPED
        }
        val url = if ("://" in raw || raw.contains(':')) raw else "https://$raw"
        val ok = ctx.device.openUrl(url, p.str("package").trim().ifEmpty { null })
        if (!ok) ctx.log("Could not open $url")
        return StepResult.DONE
    }

    override fun summary(p: Params): String = p.str("url")
}

object OpenAppAction : Action {
    override val type = "open_app"
    override val label = "Open app"
    override val description = "Bring an installed app to the front."
    override val icon = "📱"

    override val fields: List<Field> = listOf(
        Field("package", "App", Kind.APP, ""),
    )

    override suspend fun run(ctx: RunContext, step: Step, p: Params): StepResult {
        val pkg = p.str("package").trim()
        if (pkg.isEmpty()) {
            ctx.log("Open app: no app chosen")
            return StepResult.SKIPPED
        }
        if (!ctx.device.openApp(pkg)) ctx.log("Could not open $pkg (is it installed?)")
        return StepResult.DONE
    }

    override fun summary(p: Params): String = p.str("package")
}
