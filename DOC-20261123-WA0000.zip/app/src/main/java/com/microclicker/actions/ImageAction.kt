package com.microclicker.actions

import android.os.SystemClock
import com.microclicker.core.Action
import com.microclicker.core.Actions
import com.microclicker.core.Field
import com.microclicker.core.Graph
import com.microclicker.core.GuardOutcome
import com.microclicker.core.Kind
import com.microclicker.core.Match
import com.microclicker.core.Params
import com.microclicker.core.RunContext
import com.microclicker.core.Step
import com.microclicker.core.StepResult
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * The photo micro.
 *
 * Looks for a saved photo on screen. When it's there, runs ANY action ("then"): tap it, tap somewhere
 * else, swipe, open a link or app, press back, stop... When the photo shows up more than once,
 * [which] picks the copy. If acting on a copy throws the phone into a blocked app/website (see the
 * macro's Guard), it goes back and tries the next copy.
 */
object ImageAction : Action {
    override val type = "image"
    override val label = "Photo (when I see…)"
    override val description = "Wait for a photo to appear on screen, then do anything: tap it, swipe, open a link…"
    override val icon = "🖼"

    private const val SCAN_GAP_MS = 500L
    private const val MAX_TRIES = 8

    override val fields: List<Field> = listOf(
        Field("template", "Photo to look for", Kind.TEMPLATE, ""),
        Field(
            "threshold", "Match strictness", Kind.DECIMAL, "0.85",
            help = "0.70 = loose (may hit look-alikes), 0.95 = must be almost identical.",
        ),
        Field(
            "area", "Look in", Kind.CHOICE, "full",
            options = listOf(
                "full" to "Whole screen",
                "top" to "Top half",
                "bottom" to "Bottom half",
                "left" to "Left half",
                "right" to "Right half",
            ),
            help = "The whole photo must fit inside this part of the screen.",
        ),
        Field(
            "timeout", "Keep looking for", Kind.INT, "10", unit = "sec",
            help = "0 = look once and move on.",
        ),
        Field(
            "which", "If it appears several times, use", Kind.CHOICE, "best",
            options = listOf(
                "best" to "The best match",
                "top" to "The topmost",
                "bottom" to "The bottommost",
                "left" to "The leftmost",
                "right" to "The rightmost",
                "random" to "A random one",
                "nth" to "The Nth one (reading order)",
                "all" to "Every one",
            ),
        ),
        Field("nth", "Which number", Kind.INT, "1", showIf = { it.str("which") == "nth" }),
        Field("then", "When I see it", Kind.NESTED, "tap_match"),
        Field(
            "tryNext", "If that throws me somewhere blocked, go back and try the next copy",
            Kind.BOOL, "true",
            help = "Needs a Guard in the macro settings (block an app or a website).",
            showIf = { it.str("which") != "all" },
        ),
        Field(
            "onMissing", "If I never see it", Kind.CHOICE, "continue",
            options = listOf(
                "continue" to "Skip this step",
                "restart" to "Start the cycle over",
                "stop" to "Stop the macro",
            ),
        ),
    )

    override suspend fun run(ctx: RunContext, step: Step, p: Params): StepResult {
        val tid = p.str("template")
        if (!Graph.templates.exists(tid)) {
            ctx.log("Photo step: no photo chosen (or it was deleted)")
            return StepResult.SKIPPED
        }
        val name = Graph.templates.nameOf(tid)
        val threshold = p.double("threshold").coerceIn(0.3, 0.99)
        val area = p.str("area")
        val which = p.str("which")
        val tryNext = p.bool("tryNext") && which != "all" && ctx.guard.active
        val deadline = SystemClock.elapsedRealtime() + p.int("timeout").coerceAtLeast(0) * 1000L

        val tried = ArrayList<Match>()
        var attempts = 0
        var best = 0.0
        var screenFailed = false

        while (true) {
            currentCoroutineContext().ensureActive()
            val res = ctx.vision.find(tid, threshold, area, 8)
            if (res == null) {
                screenFailed = true
            } else {
                screenFailed = false
                best = max(best, res.best)
                val fresh = res.matches.filter { m ->
                    tried.none { t -> abs(t.cx - m.cx) < t.w / 2 && abs(t.cy - m.cy) < t.h / 2 }
                }
                if (fresh.isNotEmpty()) {
                    val ordered = order(fresh, which, p.int("nth"), ctx.hum.random)
                    if (which == "all") return runAll(ctx, p, name, ordered)

                    val m = ordered.first()
                    if (actOn(ctx, p, name, m) == StepResult.STOP) return StepResult.STOP
                    attempts++

                    when (ctx.guard.checkAndRecover()) {
                        GuardOutcome.STOP -> return StepResult.STOP
                        GuardOutcome.CLEAR -> return StepResult.DONE
                        GuardOutcome.RECOVERED -> {
                            if (tryNext && attempts < MAX_TRIES) {
                                tried += m
                                continue
                            }
                            return StepResult.DONE
                        }
                    }
                } else if (tried.isNotEmpty()) {
                    ctx.log("Every copy of \"$name\" led somewhere blocked, giving up on this step")
                    return StepResult.DONE
                }
            }
            if (SystemClock.elapsedRealtime() >= deadline) break
            delay(SCAN_GAP_MS)
        }

        val why = if (screenFailed) {
            "couldn't read the screen"
        } else {
            String.format(Locale.US, "best match %.2f, needed %.2f", best, threshold)
        }
        ctx.log("Photo \"$name\" not found ($why)")
        return when (p.str("onMissing")) {
            "stop" -> StepResult.STOP
            "restart" -> StepResult.RESTART_CYCLE
            else -> StepResult.SKIPPED
        }
    }

    private suspend fun actOn(ctx: RunContext, p: Params, name: String, m: Match): StepResult {
        ctx.lastMatch = m
        val thenLabel = Actions.get(p.str("then"))?.label ?: p.str("then")
        ctx.log(
            String.format(
                Locale.US, "👁 Found \"%s\" at (%d, %d), score %.2f → %s",
                name, m.cx.toInt(), m.cy.toInt(), m.score, thenLabel,
            )
        )
        return ctx.runNested(p, "then")
    }

    private suspend fun runAll(ctx: RunContext, p: Params, name: String, ordered: List<Match>): StepResult {
        for ((i, m) in ordered.withIndex()) {
            if (actOn(ctx, p, name, m) == StepResult.STOP) return StepResult.STOP
            when (ctx.guard.checkAndRecover()) {
                GuardOutcome.STOP -> return StepResult.STOP
                GuardOutcome.RECOVERED -> return StepResult.DONE // screen changed, positions are stale
                GuardOutcome.CLEAR -> Unit
            }
            if (i < ordered.lastIndex) delay(ctx.hum.delay(com.microclicker.core.Delay(150, 350)))
        }
        return StepResult.DONE
    }

    /** Orders copies by preference. The first is used; the rest are fallbacks for "try next". */
    private fun order(ms: List<Match>, which: String, nth: Int, rnd: Random): List<Match> = when (which) {
        "top" -> ms.sortedBy { it.cy }
        "bottom" -> ms.sortedByDescending { it.cy }
        "left" -> ms.sortedBy { it.cx }
        "right" -> ms.sortedByDescending { it.cx }
        "random" -> ms.shuffled(rnd)
        "nth" -> {
            // Reading order: rows top to bottom, left to right inside a row.
            val reading = ms.sortedWith(
                compareBy<Match>({ (it.cy / it.h.coerceAtLeast(1f)).roundToInt() }, { it.cx })
            )
            val i = (nth - 1).coerceIn(0, reading.lastIndex)
            listOf(reading[i]) + reading.filterIndexed { idx, _ -> idx != i }
        }
        else -> ms.sortedByDescending { it.score }
    }

    override fun summary(p: Params): String {
        val tid = p.str("template")
        val photo = if (Graph.templates.exists(tid)) "\"${Graph.templates.nameOf(tid)}\"" else "(no photo chosen)"
        val then = Actions.get(p.str("then"))?.label ?: ""
        return "$photo → $then"
    }
}
