package com.microclicker.actions

import com.microclicker.core.Action
import com.microclicker.core.Field
import com.microclicker.core.Kind
import com.microclicker.core.Params
import com.microclicker.core.RunContext
import com.microclicker.core.Step
import com.microclicker.core.StepResult
import kotlinx.coroutines.delay
import kotlin.math.hypot

object SwipeAction : Action {
    override val type = "swipe"
    override val label = "Swipe"
    override val description = "Drag from one point to another (scroll, slide, pull)."
    override val icon = "👉"
    override val mayNavigate = true

    override val fields: List<Field> = listOf(
        Field("_pick", "Draw the swipe on screen", Kind.PICK_SWIPE),
        Field("x", "From X", Kind.INT, "540", unit = "px"),
        Field("y", "From Y", Kind.INT, "1600", unit = "px"),
        Field("x2", "To X", Kind.INT, "540", unit = "px"),
        Field("y2", "To Y", Kind.INT, "700", unit = "px"),
        Field("duration", "Swipe time", Kind.INT, "300", unit = "ms", help = "Longer = slower, gentler swipe."),
        Field("count", "Repeat", Kind.INT, "1", unit = "times"),
    ) + gapFields("400") { it.int("count") > 1 }

    override suspend fun run(ctx: RunContext, step: Step, p: Params): StepResult {
        val n = p.int("count").coerceAtLeast(1)
        val w = ctx.device.screenWidth
        val h = ctx.device.screenHeight
        for (i in 0 until n) {
            val (ax, ay) = ctx.hum.point(p.int("x").toFloat(), p.int("y").toFloat(), w, h)
            val (bx, by) = ctx.hum.point(p.int("x2").toFloat(), p.int("y2").toFloat(), w, h)
            val bend = ctx.hum.swipeBend(hypot(bx - ax, by - ay))
            val ok = ctx.device.swipe(ax, ay, bx, by, ctx.hum.hold(p.long("duration")), bend)
            if (!ok) ctx.log("Android did not accept the swipe")
            if (i < n - 1) delay(ctx.hum.delay(gapOf(p)).coerceAtLeast(10L))
        }
        return StepResult.DONE
    }

    override fun summary(p: Params): String {
        val n = p.int("count")
        return "(${p.int("x")}, ${p.int("y")}) → (${p.int("x2")}, ${p.int("y2")})" + if (n > 1) " ×$n" else ""
    }
}
