package com.microclicker.actions

import com.microclicker.core.Action
import com.microclicker.core.Delay
import com.microclicker.core.Field
import com.microclicker.core.GlobalKey
import com.microclicker.core.Graph
import com.microclicker.core.Kind
import com.microclicker.core.Params
import com.microclicker.core.RunContext
import com.microclicker.core.Scope
import com.microclicker.core.Step
import com.microclicker.core.StepResult
import kotlinx.coroutines.delay

// Small actions. Good examples to copy when you add your own.

object WaitAction : Action {
    override val type = "wait"
    override val label = "Wait"
    override val description = "Do nothing for a while (a fixed time, or a random time between two values)."
    override val icon = "⏳"

    override val fields: List<Field> = listOf(
        Field("minMs", "Wait at least", Kind.INT, "1000", unit = "ms"),
        Field("maxMs", "Wait at most", Kind.INT, "1000", unit = "ms", help = "Bigger than the minimum = random wait."),
    )

    override suspend fun run(ctx: RunContext, step: Step, p: Params): StepResult {
        delay(ctx.hum.delay(Delay(p.long("minMs"), p.long("maxMs"))))
        return StepResult.DONE
    }

    override fun summary(p: Params): String {
        val a = p.long("minMs")
        val b = p.long("maxMs")
        return if (b > a) "$a–$b ms" else "$a ms"
    }
}

object SystemKeyAction : Action {
    override val type = "system_key"
    override val label = "Back / Home / Recents"
    override val description = "Press a system button."
    override val icon = "◀"

    override val fields: List<Field> = listOf(
        Field(
            "key", "Button", Kind.CHOICE, "back",
            options = listOf(
                "back" to "Back",
                "home" to "Home",
                "recents" to "Recent apps",
                "notifications" to "Pull down notifications",
                "quick_settings" to "Pull down quick settings",
                "lock_screen" to "Lock screen",
            ),
        ),
    )

    override suspend fun run(ctx: RunContext, step: Step, p: Params): StepResult {
        val key = when (p.str("key")) {
            "home" -> GlobalKey.HOME
            "recents" -> GlobalKey.RECENTS
            "notifications" -> GlobalKey.NOTIFICATIONS
            "quick_settings" -> GlobalKey.QUICK_SETTINGS
            "lock_screen" -> GlobalKey.LOCK_SCREEN
            else -> GlobalKey.BACK
        }
        ctx.device.global(key)
        return StepResult.DONE
    }

    override fun summary(p: Params): String = p.str("key")
}

/** Runs another saved macro once, right here. Lets you build big flows out of small macros. */
object RunMacroAction : Action {
    override val type = "run_macro"
    override val label = "Run another macro"
    override val description = "Run another macro's steps once, then carry on. (Uses this macro's random + guard settings.)"
    override val icon = "↪"

    override val fields: List<Field> = listOf(
        Field("macro", "Macro", Kind.MACRO, ""),
    )

    override suspend fun run(ctx: RunContext, step: Step, p: Params): StepResult {
        val target = Graph.macros.get(p.str("macro"))
        if (target == null) {
            ctx.log("Run macro: macro not found")
            return StepResult.SKIPPED
        }
        if (ctx.depth >= 4) {
            ctx.log("Run macro: nested too deep, skipped")
            return StepResult.SKIPPED
        }
        ctx.depth++
        try {
            return ctx.runner.runSteps(ctx, target.steps)
        } finally {
            ctx.depth--
        }
    }

    override fun summary(p: Params): String = Graph.macros.get(p.str("macro"))?.name ?: "(none)"
}

/** Ends the macro. Pair it with a condition, e.g. "after 600 seconds" -> stop. */
object StopAction : Action {
    override val type = "stop"
    override val label = "Stop the macro"
    override val description = "End the whole macro here. Combine with a condition (for example: after 10 minutes)."
    override val icon = "■"
    override val fields: List<Field> = emptyList()

    override suspend fun run(ctx: RunContext, step: Step, p: Params): StepResult {
        ctx.log("Stop step reached")
        return StepResult.STOP
    }
}

/** Inside a photo step: "just detect it, don't do anything" (the photo step then works as a gate). */
object NoopAction : Action {
    override val type = "noop"
    override val label = "Nothing (just wait for the photo)"
    override val description = "Do nothing."
    override val scope = Scope.NESTED_ONLY
    override val fields: List<Field> = emptyList()

    override suspend fun run(ctx: RunContext, step: Step, p: Params): StepResult = StepResult.DONE
}
