package com.microclicker.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.microclicker.data.PickKind
import com.microclicker.data.PickResult
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

// Plain Android views (no Compose) because these live in the accessibility service, not an Activity.

private val PURPLE = 0xFF6750A4.toInt()
private val GREY = 0xFF49454F.toInt()
private val RED = 0xFFB3261E.toInt()
private val ORANGE = 0xFFE8710A.toInt()
private val GREEN = 0xFF2E7D32.toInt()

private fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

internal fun fullScreenParams(): WindowManager.LayoutParams =
    WindowManager.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT,
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
    }

private fun Context.pill(label: String, color: Int): TextView = TextView(this).apply {
    text = label
    textSize = 16f
    setTextColor(Color.WHITE)
    gravity = Gravity.CENTER
    setPadding(dp(20), dp(12), dp(20), dp(12))
    background = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(24).toFloat()
        setColor(color)
    }
}

private fun Context.hintBubble(label: String): TextView = TextView(this).apply {
    text = label
    textSize = 15f
    setTextColor(Color.WHITE)
    gravity = Gravity.CENTER
    setPadding(dp(16), dp(10), dp(16), dp(10))
    background = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(16).toFloat()
        setColor(0xCC000000.toInt())
    }
}

/** The little always-on-top control: run/stop, capture a photo, pick a spot, switch macro, open the app. */
class FloatingPanel(
    private val ctx: Context,
    private val wm: WindowManager,
    private val cb: Callbacks,
) {
    interface Callbacks {
        fun onToggleRun()
        fun onCapture()
        fun onPick()
        fun onOpenApp()
        fun onNextMacro()
        fun onHide()
    }

    private fun circle(label: String, color: Int, sizeDp: Int = 46): TextView = TextView(ctx).apply {
        text = label
        textSize = 18f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        alpha = 0.93f
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
        layoutParams = LinearLayout.LayoutParams(ctx.dp(sizeDp), ctx.dp(sizeDp)).apply { marginEnd = ctx.dp(6) }
    }

    private val main = circle("▶", PURPLE, 52)
    private val more = circle("⋯", GREY, 40)
    private val capture = circle("📷", GREY)
    private val pick = circle("🎯", GREY)
    private val openApp = circle("📱", GREY)
    private val hide = circle("✕", GREY, 40)
    private val macroChip = TextView(ctx).apply {
        textSize = 13f
        setTextColor(Color.WHITE)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        maxWidth = ctx.dp(130)
        gravity = Gravity.CENTER
        setPadding(ctx.dp(12), ctx.dp(8), ctx.dp(12), ctx.dp(8))
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = ctx.dp(20).toFloat()
            setColor(GREY)
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
        ).apply { marginEnd = ctx.dp(6) }
    }

    private val extras = listOf<View>(capture, pick, macroChip, openApp, hide)

    private val row = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(main)
        addView(more)
        extras.forEach { addView(it) }
    }

    private val lp = WindowManager.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT,
        ViewGroup.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT,
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = ctx.dp(8)
        y = ctx.dp(220)
    }

    private var attached = false
    private var expanded = false

    init {
        // Drag by the big button; a tap (no drag) runs / stops the macro.
        main.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0f
            var startY = 0f
            var originX = 0
            var originY = 0
            var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = e.rawX
                        startY = e.rawY
                        originX = lp.x
                        originY = lp.y
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - startX
                        val dy = e.rawY - startY
                        if (!moved && hypot(dx, dy) > ctx.dp(8)) moved = true
                        if (moved && attached) {
                            lp.x = originX + dx.toInt()
                            lp.y = originY + dy.toInt()
                            wm.updateViewLayout(row, lp)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) cb.onToggleRun()
                        return true
                    }
                }
                return false
            }
        })
        more.setOnClickListener {
            expanded = !expanded
            applyExpanded()
        }
        capture.setOnClickListener { cb.onCapture() }
        pick.setOnClickListener { cb.onPick() }
        openApp.setOnClickListener { cb.onOpenApp() }
        macroChip.setOnClickListener { cb.onNextMacro() }
        hide.setOnClickListener { cb.onHide() }
        applyExpanded()
    }

    private fun applyExpanded() {
        extras.forEach { it.visibility = if (expanded) View.VISIBLE else View.GONE }
        more.text = if (expanded) "‹" else "⋯"
        if (attached) runCatching { wm.updateViewLayout(row, lp) }
    }

    fun show() {
        if (attached) return
        runCatching {
            wm.addView(row, lp)
            attached = true
        }
    }

    fun destroy() {
        if (!attached) return
        runCatching { wm.removeView(row) }
        attached = false
    }

    /** Hide without removing (used while taking a screenshot so the panel isn't in the picture). */
    fun setVisible(v: Boolean) {
        row.visibility = if (v) View.VISIBLE else View.INVISIBLE
    }

    fun update(running: Boolean, macroName: String, pickPending: Boolean) {
        main.text = if (running) "■" else "▶"
        (main.background as GradientDrawable).setColor(if (running) RED else PURPLE)
        macroChip.text = "⇄ " + macroName.ifBlank { "no macro" }
        (pick.background as GradientDrawable).setColor(if (pickPending) ORANGE else GREY)
        if (pickPending && !expanded) {
            expanded = true
            applyExpanded()
        }
        setKeepAwake(running)
    }

    /** While a macro runs, stop the screen from going to sleep (a sleeping screen can't be clicked). */
    private fun setKeepAwake(on: Boolean) {
        val flag = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        val has = (lp.flags and flag) != 0
        if (on == has) return
        lp.flags = if (on) lp.flags or flag else lp.flags and flag.inv()
        if (attached) runCatching { wm.updateViewLayout(row, lp) }
    }
}

/** Frozen screenshot; the user drags a box; Save turns the box into a library photo. */
class CropOverlay(
    ctx: Context,
    private val shot: Bitmap,
    private val onSave: (Bitmap) -> Unit,
    private val onCancel: () -> Unit,
) : FrameLayout(ctx) {

    private val cropView = CropView(ctx, shot)

    init {
        addView(cropView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val hint = ctx.hintBubble("Drag a box around the thing you want to find")
        addView(
            hint,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = ctx.dp(72) },
        )

        val save = ctx.pill("Save photo", GREEN).apply {
            setOnClickListener {
                val crop = cropView.cropped()
                if (crop == null) {
                    hint.text = "Draw a bigger box first"
                } else {
                    onSave(crop)
                }
            }
        }
        val cancel = ctx.pill("Cancel", GREY).apply { setOnClickListener { onCancel() } }
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(cancel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = ctx.dp(12) })
            addView(save)
        }
        addView(
            bar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = ctx.dp(96) },
        )
    }

    fun recycle() {
        shot.recycle()
    }

    private class CropView(ctx: Context, private val shot: Bitmap) : View(ctx) {
        private var sel: RectF? = null
        private var sx = 0f
        private var sy = 0f
        private val dim = Paint().apply { color = 0x99000000.toInt() }
        private val border = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = ctx.dp(2).toFloat()
        }

        override fun onDraw(c: Canvas) {
            val dst = RectF(0f, 0f, width.toFloat(), height.toFloat())
            c.drawBitmap(shot, null, dst, null)
            c.drawRect(dst, dim)
            sel?.let { r ->
                c.save()
                c.clipRect(r)
                c.drawBitmap(shot, null, dst, null)
                c.restore()
                c.drawRect(r, border)
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.x
                    sy = e.y
                    sel = RectF(sx, sy, sx, sy)
                }
                MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                    sel = RectF(min(sx, e.x), min(sy, e.y), max(sx, e.x), max(sy, e.y))
                }
            }
            invalidate()
            return true
        }

        /** The boxed part of the screenshot, or null if there is no usable box. */
        fun cropped(): Bitmap? {
            val r = sel ?: return null
            if (width == 0 || height == 0) return null
            val kx = shot.width / width.toFloat()
            val ky = shot.height / height.toFloat()
            val x = (r.left * kx).toInt().coerceIn(0, shot.width - 1)
            val y = (r.top * ky).toInt().coerceIn(0, shot.height - 1)
            val w = ((r.right - r.left) * kx).toInt().coerceAtMost(shot.width - x)
            val h = ((r.bottom - r.top) * ky).toInt().coerceAtMost(shot.height - y)
            if (w < 12 || h < 12) return null
            return Bitmap.createBitmap(shot, x, y, w, h)
        }
    }
}

/** See-through layer on top of the live screen: tap a spot, or drag to draw a swipe. */
class PickOverlay(
    ctx: Context,
    private val token: Long,
    private val kind: PickKind,
    private val onResult: (PickResult) -> Unit,
    private val onCancel: () -> Unit,
) : FrameLayout(ctx) {

    private val view = PickView(ctx)

    init {
        addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val text = when (kind) {
            PickKind.SWIPE -> "Drag on the screen from where the swipe starts to where it ends"
            PickKind.POINT_LIST -> "Touch the spot to add (you can slide to fine-tune, lift to confirm)"
            else -> "Touch the spot to tap (you can slide to fine-tune, lift to confirm)"
        }
        addView(
            ctx.hintBubble(text),
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = ctx.dp(72) },
        )
        addView(
            ctx.pill("Cancel", GREY).apply { setOnClickListener { onCancel() } },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = ctx.dp(96) },
        )
    }

    private inner class PickView(ctx: Context) : View(ctx) {
        private var x1 = 0f
        private var y1 = 0f
        private var x2 = 0f
        private var y2 = 0f
        private var downAt = 0L
        private var active = false

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ORANGE
            strokeWidth = ctx.dp(3).toFloat()
            style = Paint.Style.STROKE
        }

        init {
            setBackgroundColor(0x33000000)
        }

        override fun onDraw(c: Canvas) {
            if (!active) return
            val r = ctx.dp(18).toFloat()
            if (kind == PickKind.SWIPE) {
                c.drawLine(x1, y1, x2, y2, paint)
                c.drawCircle(x1, y1, r * 0.6f, paint)
            }
            c.drawCircle(x2, y2, r, paint)
            c.drawLine(x2 - r * 1.6f, y2, x2 + r * 1.6f, y2, paint)
            c.drawLine(x2, y2 - r * 1.6f, x2, y2 + r * 1.6f, paint)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    x1 = e.rawX; y1 = e.rawY; x2 = x1; y2 = y1
                    downAt = e.eventTime
                    active = true
                }
                MotionEvent.ACTION_MOVE -> {
                    x2 = e.rawX; y2 = e.rawY
                }
                MotionEvent.ACTION_UP -> {
                    x2 = e.rawX; y2 = e.rawY
                    val dur = (e.eventTime - downAt).coerceIn(100L, 2000L)
                    if (kind == PickKind.SWIPE) {
                        onResult(PickResult(token, kind, x1.toInt(), y1.toInt(), x2.toInt(), y2.toInt(), dur))
                    } else {
                        onResult(PickResult(token, kind, x2.toInt(), y2.toInt(), x2.toInt(), y2.toInt(), 0))
                    }
                }
                MotionEvent.ACTION_CANCEL -> active = false
            }
            invalidate()
            return true
        }
    }
}
