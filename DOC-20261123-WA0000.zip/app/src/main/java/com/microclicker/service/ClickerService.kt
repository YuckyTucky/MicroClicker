package com.microclicker.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.GestureResultCallback
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.net.Uri
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import com.microclicker.core.Device
import com.microclicker.core.Engine
import com.microclicker.core.GlobalKey
import com.microclicker.core.Graph
import com.microclicker.data.PickBridge
import com.microclicker.data.PickKind
import com.microclicker.data.PickResult
import com.microclicker.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.hypot

/**
 * The hands and eyes of the app. Android lets accessibility services inject taps/swipes and read
 * the screen, so this is where macros turn into real touches. Everything else is plain Kotlin.
 */
class ClickerService : AccessibilityService(), Device, FloatingPanel.Callbacks {

    private var scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val shotExecutor = Executors.newSingleThreadExecutor()

    private lateinit var wm: WindowManager
    private var panel: FloatingPanel? = null
    private var overlay: android.view.View? = null

    @Volatile
    private var lastEventPackage: String? = null

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        scope.cancel()
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
        Engine.attach(this)

        // Keep the floating panel in sync with everything that can change it.
        scope.launch { Graph.prefs.showBubble.collect { refreshPanel() } }
        scope.launch { Engine.state.collect { refreshPanel() } }
        scope.launch { Graph.prefs.selectedMacroId.collect { refreshPanel() } }
        scope.launch { Graph.macros.macros.collect { refreshPanel() } }
        scope.launch { PickBridge.request.collect { refreshPanel() } }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        teardown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun teardown() {
        Engine.detach(this)
        removeOverlay()
        panel?.destroy()
        panel = null
        scope.cancel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            event.packageName?.toString()?.let { lastEventPackage = it }
        }
    }

    override fun onInterrupt() = Unit

    // ---------------------------------------------------------------- Device: gestures

    override val screenWidth: Int
        get() = (getSystemService(WINDOW_SERVICE) as WindowManager).maximumWindowMetrics.bounds.width()

    override val screenHeight: Int
        get() = (getSystemService(WINDOW_SERVICE) as WindowManager).maximumWindowMetrics.bounds.height()

    private suspend fun dispatch(g: GestureDescription): Boolean = suspendCancellableCoroutine { cont ->
        val callback = object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (cont.isActive) cont.resume(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (cont.isActive) cont.resume(false)
            }
        }
        val accepted = dispatchGesture(g, callback, null)
        if (!accepted && cont.isActive) cont.resume(false)
    }

    override suspend fun tap(x: Float, y: Float, holdMs: Long): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, holdMs.coerceIn(1L, 60_000L))
        return dispatch(GestureDescription.Builder().addStroke(stroke).build())
    }

    override suspend fun swipe(
        x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long, bend: Float,
    ): Boolean {
        val path = Path().apply {
            moveTo(x1, y1)
            if (abs(bend) < 1f) {
                lineTo(x2, y2)
            } else {
                // A quadratic curve's midpoint sits halfway to its control point, so double the bend.
                val dx = x2 - x1
                val dy = y2 - y1
                val len = hypot(dx, dy).coerceAtLeast(1f)
                val cx = (x1 + x2) / 2f + (-dy / len) * bend * 2f
                val cy = (y1 + y2) / 2f + (dx / len) * bend * 2f
                quadTo(cx, cy, x2, y2)
            }
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceIn(1L, 60_000L))
        return dispatch(GestureDescription.Builder().addStroke(stroke).build())
    }

    override suspend fun multiTouch(points: List<Pair<Float, Float>>, holdMs: Long): Boolean {
        val builder = GestureDescription.Builder()
        val limit = GestureDescription.getMaxStrokeCount()
        for ((x, y) in points.take(limit)) {
            val path = Path().apply { moveTo(x, y) }
            builder.addStroke(GestureDescription.StrokeDescription(path, 0L, holdMs.coerceIn(1L, 60_000L)))
        }
        return dispatch(builder.build())
    }

    // ---------------------------------------------------------------- Device: eyes

    /** Android 11+ lets accessibility services grab the screen without a screen-recording prompt. */
    override suspend fun screenshot(): Bitmap? = suspendCancellableCoroutine { cont ->
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, shotExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    val bmp: Bitmap? = try {
                        val buffer = screenshot.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(buffer, screenshot.colorSpace)
                        val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                        buffer.close()
                        soft
                    } catch (e: Throwable) {
                        null
                    }
                    if (cont.isActive) cont.resume(bmp)
                }

                override fun onFailure(errorCode: Int) {
                    Engine.log("Screenshot failed (code $errorCode)")
                    if (cont.isActive) cont.resume(null)
                }
            })
        } catch (e: Throwable) {
            if (cont.isActive) cont.resume(null)
        }
    }

    override fun foregroundPackage(): String? {
        val fromWindow = try {
            rootInActiveWindow?.packageName?.toString()
        } catch (e: Throwable) {
            null
        }
        return fromWindow ?: lastEventPackage
    }

    override fun currentUrl(): String? {
        val root = try {
            rootInActiveWindow
        } catch (e: Throwable) {
            null
        } ?: return null
        val pkg = root.packageName?.toString() ?: return null

        for (suffix in URL_BAR_IDS) {
            val nodes = try {
                root.findAccessibilityNodeInfosByViewId("$pkg:id/$suffix")
            } catch (e: Throwable) {
                null
            }
            val text = nodes?.firstOrNull()?.text?.toString()
            if (!text.isNullOrBlank()) return text
        }
        return scanForUrl(root)
    }

    /** Fallback for browsers we don't know: first node whose id mentions "url" and has text. */
    private fun scanForUrl(root: AccessibilityNodeInfo): String? {
        val queue = ArrayList<AccessibilityNodeInfo>()
        queue.add(root)
        var head = 0
        var seen = 0
        while (head < queue.size && seen < 250) {
            val node = queue[head++]
            seen++
            val id = node.viewIdResourceName?.lowercase()
            val text = node.text?.toString()
            if (id != null && id.contains("url") && !text.isNullOrBlank()) return text
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it) }
            }
        }
        return null
    }

    // ---------------------------------------------------------------- Device: navigation

    override fun global(key: GlobalKey): Boolean = performGlobalAction(
        when (key) {
            GlobalKey.BACK -> GLOBAL_ACTION_BACK
            GlobalKey.HOME -> GLOBAL_ACTION_HOME
            GlobalKey.RECENTS -> GLOBAL_ACTION_RECENTS
            GlobalKey.NOTIFICATIONS -> GLOBAL_ACTION_NOTIFICATIONS
            GlobalKey.QUICK_SETTINGS -> GLOBAL_ACTION_QUICK_SETTINGS
            GlobalKey.LOCK_SCREEN -> GLOBAL_ACTION_LOCK_SCREEN
        }
    )

    override fun openUrl(url: String, pkg: String?): Boolean = try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!pkg.isNullOrBlank()) intent.setPackage(pkg)
        startActivity(intent)
        true
    } catch (e: Throwable) {
        false
    }

    override fun openApp(pkg: String): Boolean = try {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            false
        } else {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            true
        }
    } catch (e: Throwable) {
        false
    }

    // ---------------------------------------------------------------- floating panel

    private fun refreshPanel() {
        if (!::wm.isInitialized) return
        val request = PickBridge.request.value
        val wanted = Graph.prefs.showBubble.value || request != null
        if (!wanted) {
            panel?.destroy()
            panel = null
            return
        }
        val p = panel ?: FloatingPanel(this, wm, this).also {
            panel = it
            it.show()
        }
        val macroName = Graph.macros.get(Graph.prefs.selectedMacroId.value)?.name ?: ""
        p.update(Engine.state.value.running, macroName, request != null)
    }

    override fun onToggleRun() = Engine.toggleSelected()

    override fun onCapture() = beginCapture()

    override fun onPick() {
        val req = PickBridge.request.value
        when {
            req == null -> toast("Nothing to pick right now. Start from a step in the app.")
            req.kind == PickKind.CAPTURE -> beginCapture()
            else -> showPick(req.token, req.kind)
        }
    }

    override fun onOpenApp() = bringAppToFront()

    override fun onNextMacro() {
        val list = Graph.macros.macros.value
        if (list.isEmpty()) return
        val idx = list.indexOfFirst { it.id == Graph.prefs.selectedMacroId.value }
        val next = list[(idx + 1) % list.size]
        Graph.prefs.selectMacro(next.id)
        toast("Selected: ${next.name}")
    }

    override fun onHide() {
        Graph.prefs.setBubble(false)
        PickBridge.clear()
        toast("Floating control hidden. Turn it back on in the app.")
    }

    // ---------------------------------------------------------------- capture a photo

    private fun beginCapture() {
        if (overlay != null) return
        panel?.setVisible(false)
        scope.launch {
            delay(250) // let the panel actually disappear before the screenshot
            val bmp = screenshot()
            panel?.setVisible(true)
            if (bmp == null) {
                toast("Couldn't take a screenshot (Android 11+ needed)")
                return@launch
            }
            val view = CropOverlay(
                this@ClickerService, bmp,
                onSave = { crop ->
                    val t = Graph.templates.add(crop)
                    removeOverlay()
                    toast("Saved \"${t.name}\" to your photo library")
                    val req = PickBridge.request.value
                    if (req != null && req.kind == PickKind.CAPTURE) {
                        PickBridge.deliver(PickResult(req.token, PickKind.CAPTURE, templateId = t.id))
                        bringAppToFront()
                    }
                },
                onCancel = { removeOverlay() },
            )
            showOverlay(view)
        }
    }

    // ---------------------------------------------------------------- pick a spot / swipe

    private fun showPick(token: Long, kind: PickKind) {
        if (overlay != null) return
        val view = PickOverlay(
            this, token, kind,
            onResult = { result ->
                removeOverlay()
                PickBridge.deliver(result)
                bringAppToFront()
            },
            onCancel = { removeOverlay() },
        )
        showOverlay(view)
    }

    // ---------------------------------------------------------------- helpers

    private fun showOverlay(v: android.view.View) {
        removeOverlay()
        runCatching {
            wm.addView(v, fullScreenParams())
            overlay = v
        }
    }

    private fun removeOverlay() {
        val v = overlay ?: return
        runCatching { wm.removeView(v) }
        overlay = null
    }

    private fun bringAppToFront() {
        val intent = Intent(this, MainActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP
        )
        runCatching { startActivity(intent) }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        /** Typical address-bar view ids (the part after "<package>:id/"). */
        val URL_BAR_IDS = listOf(
            "url_bar",                        // Chrome, Edge, Brave, Vivaldi, Kiwi
            "url_bar_title",                  // Firefox
            "mozac_browser_toolbar_url_view", // Firefox / Mozilla Android Components
            "location_bar_edit_text",         // Samsung Internet
            "url_field",                      // Opera
            "url",
        )
    }
}
