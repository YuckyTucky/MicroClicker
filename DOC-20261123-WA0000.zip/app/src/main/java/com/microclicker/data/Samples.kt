package com.microclicker.data

import com.microclicker.core.Condition
import com.microclicker.core.Delay
import com.microclicker.core.Graph
import com.microclicker.core.HumanizePresets
import com.microclicker.core.Macro
import com.microclicker.core.Params
import com.microclicker.core.Step
import com.microclicker.core.Timing

/** Two starter macros on first launch, so the app isn't empty and shows how steps fit together. */
object Samples {
    fun seedIfNeeded() {
        val prefs = Graph.prefs
        if (prefs.seeded) return
        prefs.seeded = true
        if (Graph.macros.macros.value.isNotEmpty()) return

        val steady = Macro(
            name = "Example: steady auto clicker",
            steps = listOf(
                Step(
                    type = "tap",
                    name = "Tap the middle",
                    params = Params().set("x", 540).set("y", 1200).obj,
                    timing = Timing(after = Delay(800, 1600)),
                ),
            ),
            humanize = HumanizePresets.LIGHT,
        )

        val photo = Macro(
            name = "Example: photo + swipe every 3rd cycle",
            steps = listOf(
                Step(
                    type = "image",
                    name = "Click my photo (choose a photo first)",
                    params = Params().set("timeout", 5).obj,
                ),
                Step(
                    type = "swipe",
                    name = "Scroll down every 3rd cycle",
                    params = Params().set("x", 540).set("y", 1600).set("x2", 540).set("y2", 700).obj,
                    conditions = listOf(Condition("cycle_every", "3")),
                ),
            ),
        )

        Graph.macros.save(steady)
        Graph.macros.save(photo)
        prefs.selectMacro(steady.id)
    }
}
