package com.microclicker.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import com.microclicker.core.AppJson
import com.microclicker.core.Ids
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

data class Template(val id: String, val name: String)

/** The photo library: small PNG files plus a name index. Macros refer to photos by id. */
class TemplateStore(private val dir: File) {
    private val indexFile = File(dir, "index.json")
    private val names = HashMap<String, String>()
    private val indexSerializer = MapSerializer(String.serializer(), String.serializer())
    private val thumbs = LruCache<String, Bitmap>(48)

    private val _templates = MutableStateFlow<List<Template>>(emptyList())
    val templates: StateFlow<List<Template>> = _templates.asStateFlow()

    init {
        dir.mkdirs()
        runCatching {
            if (indexFile.exists()) names.putAll(AppJson.decodeFromString(indexSerializer, indexFile.readText()))
        }
        refresh()
    }

    private fun saveIndex() {
        indexFile.writeText(AppJson.encodeToString(indexSerializer, names))
    }

    private fun refresh() {
        val ids = dir.listFiles { f -> f.extension == "png" }?.map { it.nameWithoutExtension } ?: emptyList()
        _templates.value = ids.map { Template(it, names[it] ?: it) }.sortedBy { it.name.lowercase() }
    }

    fun file(id: String): File = File(dir, "$id.png")

    fun exists(id: String): Boolean = id.isNotEmpty() && file(id).exists()

    fun nameOf(id: String): String = names[id] ?: id

    private fun nextName(): String {
        var n = 1
        while (names.values.contains("Photo $n")) n++
        return "Photo $n"
    }

    fun add(bitmap: Bitmap, name: String? = null): Template {
        val id = Ids.new()
        FileOutputStream(file(id)).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val finalName = name?.takeIf { it.isNotBlank() } ?: nextName()
        names[id] = finalName
        saveIndex()
        refresh()
        return Template(id, finalName)
    }

    /** Used when importing a macro pack that carries its photos. */
    fun addRaw(id: String, name: String, png: ByteArray) {
        file(id).writeBytes(png)
        names[id] = name.ifBlank { nextName() }
        thumbs.remove(id)
        saveIndex()
        refresh()
    }

    fun importFrom(input: InputStream, name: String? = null): Template? {
        val bmp = BitmapFactory.decodeStream(input) ?: return null
        val t = add(bmp, name)
        bmp.recycle()
        return t
    }

    fun rename(id: String, name: String) {
        if (name.isBlank()) return
        names[id] = name.trim()
        saveIndex()
        refresh()
    }

    fun delete(id: String) {
        file(id).delete()
        names.remove(id)
        thumbs.remove(id)
        saveIndex()
        refresh()
    }

    /** Small preview for lists. Cached. */
    fun thumb(id: String, maxPx: Int = 192): Bitmap? {
        thumbs.get(id)?.let { return it }
        val f = file(id)
        if (!f.exists()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxPx && bounds.outHeight / (sample * 2) >= maxPx) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = BitmapFactory.decodeFile(f.absolutePath, opts) ?: return null
        thumbs.put(id, bmp)
        return bmp
    }
}
