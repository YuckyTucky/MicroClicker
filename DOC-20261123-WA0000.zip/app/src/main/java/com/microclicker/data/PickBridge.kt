package com.microclicker.data

import kotlinx.coroutines.flow.MutableStateFlow

enum class PickKind { TAP, SWIPE, POINT_LIST, CAPTURE }

/** "I'd like a point / swipe / screenshot-crop from the screen." Set by the editor. */
data class PickRequest(val kind: PickKind, val token: Long = System.nanoTime())

/** The answer, filled in by the accessibility service's overlays. */
data class PickResult(
    val token: Long,
    val kind: PickKind,
    val x1: Int = 0,
    val y1: Int = 0,
    val x2: Int = 0,
    val y2: Int = 0,
    val durationMs: Long = 0,
    val templateId: String = "",
)

/**
 * Hand-off between the app UI and the on-screen overlays (which live in the accessibility service).
 * StateFlows (not events) so a result that arrives while the app is in the background is still there
 * when the user comes back.
 */
object PickBridge {
    val request = MutableStateFlow<PickRequest?>(null)
    val result = MutableStateFlow<PickResult?>(null)

    fun ask(kind: PickKind): PickRequest {
        val r = PickRequest(kind)
        result.value = null
        request.value = r
        return r
    }

    fun deliver(r: PickResult) {
        result.value = r
    }

    fun clear() {
        request.value = null
        result.value = null
    }
}
