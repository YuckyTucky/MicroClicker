package com.microclicker.data

import android.util.Base64
import com.microclicker.core.AppJson
import com.microclicker.core.Graph
import com.microclicker.core.Ids
import com.microclicker.core.Macro
import kotlinx.serialization.Serializable

@Serializable
data class TemplateBlob(val name: String = "", val png: String = "")

/** A macro bundled with the photos it uses, so it works on another phone. */
@Serializable
data class MacroPack(
    val format: String = "microclicker-pack-1",
    val macro: Macro,
    val templates: Map<String, TemplateBlob> = emptyMap(),
)

object Packs {
    /** Macro + every library photo whose id appears in it, as one JSON string. */
    fun export(macro: Macro): String {
        val macroJson = AppJson.encodeToString(Macro.serializer(), macro)
        val blobs = LinkedHashMap<String, TemplateBlob>()
        for (t in Graph.templates.templates.value) {
            if (macroJson.contains("\"${t.id}\"")) {
                val f = Graph.templates.file(t.id)
                if (f.exists()) {
                    blobs[t.id] = TemplateBlob(t.name, Base64.encodeToString(f.readBytes(), Base64.NO_WRAP))
                }
            }
        }
        return AppJson.encodeToString(MacroPack.serializer(), MacroPack(macro = macro, templates = blobs))
    }

    /** Accepts a pack or a bare macro JSON. Saves and returns the macro. Throws on invalid input. */
    fun import(text: String): Macro {
        val t = text.trim()
        val pack = runCatching { AppJson.decodeFromString(MacroPack.serializer(), t) }.getOrNull()
        val macro: Macro
        if (pack != null) {
            pack.templates.forEach { (id, blob) ->
                if (!Graph.templates.exists(id)) {
                    Graph.templates.addRaw(id, blob.name, Base64.decode(blob.png, Base64.DEFAULT))
                }
            }
            macro = pack.macro
        } else {
            macro = AppJson.decodeFromString(Macro.serializer(), t)
        }
        val fresh = if (Graph.macros.get(macro.id) != null) {
            macro.copy(id = Ids.new(), name = macro.name + " (imported)")
        } else {
            macro
        }
        Graph.macros.save(fresh)
        return fresh
    }
}
