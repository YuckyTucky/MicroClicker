package com.microclicker.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

/** Small app settings. Flows so the UI and the floating bubble update live. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    /** Which macro the floating ▶ button runs. */
    val selectedMacroId = MutableStateFlow(sp.getString("selected", "") ?: "")

    /** Show the floating control while the service is on. */
    val showBubble = MutableStateFlow(sp.getBoolean("bubble", true))

    var seeded: Boolean
        get() = sp.getBoolean("seeded", false)
        set(v) {
            sp.edit().putBoolean("seeded", v).apply()
        }

    fun selectMacro(id: String) {
        sp.edit().putString("selected", id).apply()
        selectedMacroId.value = id
    }

    fun setBubble(v: Boolean) {
        sp.edit().putBoolean("bubble", v).apply()
        showBubble.value = v
    }
}
