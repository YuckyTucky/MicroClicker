package com.microclicker.data

import com.microclicker.core.AppJson
import com.microclicker.core.Ids
import com.microclicker.core.Macro
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File

/** Macros are plain JSON files in the app's private folder: easy to back up, diff and hand-edit. */
class MacroRepository(private val dir: File) {
    private val _macros = MutableStateFlow<List<Macro>>(emptyList())
    val macros: StateFlow<List<Macro>> = _macros.asStateFlow()

    init {
        dir.mkdirs()
        reload()
    }

    private fun file(id: String) = File(dir, "$id.json")

    fun reload() {
        val loaded = dir.listFiles { f -> f.extension == "json" }
            ?.mapNotNull { f ->
                runCatching { AppJson.decodeFromString(Macro.serializer(), f.readText()) }.getOrNull()
            }
            ?: emptyList()
        _macros.value = loaded.sortedBy { it.name.lowercase() }
    }

    fun get(id: String): Macro? = _macros.value.firstOrNull { it.id == id }

    fun save(m: Macro) {
        file(m.id).writeText(AppJson.encodeToString(Macro.serializer(), m))
        _macros.update { list ->
            val next = if (list.any { it.id == m.id }) list.map { if (it.id == m.id) m else it } else list + m
            next.sortedBy { it.name.lowercase() }
        }
    }

    fun delete(id: String) {
        file(id).delete()
        _macros.update { list -> list.filter { it.id != id } }
    }

    fun duplicate(id: String): Macro? {
        val src = get(id) ?: return null
        val copy = src.copy(id = Ids.new(), name = src.name + " (copy)")
        save(copy)
        return copy
    }

    /** Replace everything about a macro from raw JSON (used by the JSON editor). Throws if invalid. */
    fun parse(json: String): Macro = AppJson.decodeFromString(Macro.serializer(), json)

    fun toJson(m: Macro): String = AppJson.encodeToString(Macro.serializer(), m)
}
