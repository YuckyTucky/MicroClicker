package com.microclicker.conditions

import com.microclicker.core.Condition
import com.microclicker.core.RunContext

/** What kind of value a condition needs (decides which input the editor shows). */
enum class ValueKind { NUMBER, TEMPLATE, STEP, APP }

/**
 * A rule a step can be gated by. All conditions on a step must be true for it to run.
 *
 * ===== HOW TO ADD A NEW CONDITION =====
 * Add one `Cond(...)` line to the list in [Conditions] below. The editor picks it up automatically.
 */
interface ConditionType {
    val type: String
    val label: String
    val kind: ValueKind
    val hint: String get() = ""
    val valueDefault: String get() = ""
    val secondLabel: String? get() = null
    val secondDefault: String get() = ""
    suspend fun eval(ctx: RunContext, c: Condition): Boolean
}

private class Cond(
    override val type: String,
    override val label: String,
    override val kind: ValueKind,
    override val hint: String = "",
    override val valueDefault: String = "",
    override val secondLabel: String? = null,
    override val secondDefault: String = "",
    private val test: suspend (RunContext, Condition) -> Boolean,
) : ConditionType {
    override suspend fun eval(ctx: RunContext, c: Condition): Boolean = test(ctx, c)
}

private fun Condition.n(): Int = value.trim().toIntOrNull() ?: 0

private suspend fun photoVisible(ctx: RunContext, c: Condition): Boolean? {
    val score = c.value2.trim().replace(',', '.').toDoubleOrNull() ?: 0.85
    val res = ctx.vision.find(c.value, score.coerceIn(0.3, 0.99), "full", 1, maxAgeMs = 350) ?: return null
    return res.matches.isNotEmpty()
}

object Conditions {
    private val list: List<ConditionType> = listOf(
        // --- by cycle (one cycle = one full pass through the steps) ---
        Cond("cycle_from", "From cycle number … onward", ValueKind.NUMBER, "3 = from the 3rd cycle on", "3") { ctx, c ->
            ctx.cycle >= c.n()
        },
        Cond("cycle_until", "Only until cycle number …", ValueKind.NUMBER, "5 = cycles 1 to 5", "5") { ctx, c ->
            ctx.cycle <= c.n()
        },
        Cond("cycle_every", "Every N-th cycle", ValueKind.NUMBER, "3 = cycles 3, 6, 9…", "3") { ctx, c ->
            c.n() > 0 && ctx.cycle % c.n() == 0
        },

        // --- by time since the macro started ---
        Cond("time_after", "After … seconds of running", ValueKind.NUMBER, "seconds since you pressed start", "60") { ctx, c ->
            ctx.elapsedSec >= c.n()
        },
        Cond("time_before", "Before … seconds of running", ValueKind.NUMBER, "seconds since you pressed start", "60") { ctx, c ->
            ctx.elapsedSec < c.n()
        },

        // --- by other steps ("after / before another micro") ---
        Cond(
            "after_step", "After another step has run", ValueKind.STEP,
            secondLabel = "at least this many times", secondDefault = "1",
        ) { ctx, c ->
            (ctx.stepRuns[c.value] ?: 0) >= maxOf(1, c.value2.trim().toIntOrNull() ?: 1)
        },
        Cond("before_step", "Until another step has run", ValueKind.STEP) { ctx, c ->
            (ctx.stepRuns[c.value] ?: 0) == 0
        },

        // --- by what's on screen ---
        Cond(
            "image_seen", "When this photo is on screen", ValueKind.TEMPLATE,
            secondLabel = "match strictness (0.5–0.99)", secondDefault = "0.85",
        ) { ctx, c -> photoVisible(ctx, c) == true },
        Cond(
            "image_not_seen", "When this photo is NOT on screen", ValueKind.TEMPLATE,
            secondLabel = "match strictness (0.5–0.99)", secondDefault = "0.85",
        ) { ctx, c -> photoVisible(ctx, c) == false },
        Cond("app_foreground", "When this app is in front", ValueKind.APP) { ctx, c ->
            ctx.device.foregroundPackage() == c.value
        },
        Cond("app_not_foreground", "When this app is NOT in front", ValueKind.APP) { ctx, c ->
            val fg = ctx.device.foregroundPackage()
            fg != null && fg != c.value
        },

        // --- randomness ---
        Cond("chance", "Only some of the time (%)", ValueKind.NUMBER, "50 = about every other time", "50") { ctx, c ->
            ctx.hum.chance(c.n())
        },
    )

    fun get(type: String): ConditionType? = list.firstOrNull { it.type == type }
    fun all(): List<ConditionType> = list
}
