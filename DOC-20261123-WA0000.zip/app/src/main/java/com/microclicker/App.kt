package com.microclicker

import android.app.Application
import com.microclicker.core.Graph

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Graph.init(this)
    }
}
