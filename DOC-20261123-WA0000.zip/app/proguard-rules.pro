# Minification is off by default. If you turn it on, keep serialization + OpenCV:
-keep class org.opencv.** { *; }
-keepclassmembers class com.microclicker.core.** { *; }
