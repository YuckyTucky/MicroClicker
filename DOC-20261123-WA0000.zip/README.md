# Micro Clicker

An Android auto-clicker built from small "micros" you snap together:

| # | Feature | Where |
|---|---------|-------|
| 1-A | **Photo micro**: give it a photo; when it sees it on screen it does *any* action (tap it, tap elsewhere, swipe, open a link/app, press Back, stop…) | Step type "Photo" |
| 1-B | **Same photo twice?** Pick which copy (best / top / bottom / left / right / random / Nth / every one). If a click throws you into a blocked app or website, it goes back and **tries the next copy**, or does something else entirely instead of clicking | Photo step + **Guard** |
| 2 | **Link / website micro** | Step type "Open website / link" |
| 3-A | **Auto clicker + swipe** | Steps "Tap", "Swipe" |
| 3-B | **Multi-click**, custom timing, run after another micro, conditions (before/after, every 3rd cycle, after N seconds…) | Tap count, "Multi-tap", **Conditions** on any step |
| 4 | **Randomised** timing / position / press time / long pauses, for AFK & bot checks | per-step min–max ranges + **Look human** |
| 5 | Simple app | Home → New macro → Add step |
| 6 | Easy to change & update | see **Extending** below |

## Build it

**Option A: Android Studio.** Open this folder, let Gradle sync, press Run (or Build > Build APK). Needs Android Studio with JDK 17.

**Option B: GitHub (no install).** Push this folder to a GitHub repo. `.github/workflows/build.yml` builds the APK; download it from Actions > latest run > Artifacts.

Requires **Android 11 or newer** (that's what lets the app see the screen without a screen-recording prompt).

> This project was written without being able to compile it on the machine that produced it. If your first build shows a compile error, send me the message and I'll fix it.

## First-time setup on the phone

1. Install the APK and open **Micro Clicker**.
2. Tap **Open Accessibility settings** > Micro Clicker > turn it **on**.
   *Android 13+, switch greyed out?* Settings > Apps > Micro Clicker > ⋮ > **Allow restricted settings**, then try again.
3. A small floating control appears: **▶/■** run/stop (drag it to move), **⋯** for more: **📷** capture a photo, **🎯** pick a spot, **⇄** switch macro, **📱** open the app.

## Making your first macro

1. **New macro** > **Add step** > **Photo**.
2. **Choose** the photo > **From screen**: the app hides; go to the right screen, tap **📷** on the floating control, drag a box around the thing, **Save photo**. You land back in the editor with it selected.
3. Leave "When I see it" on *Tap the photo* (or switch it to Open link, Swipe, Stop…).
4. Back to Home > **▶ Run** (3-second countdown so you can switch to your game/app) or press **▶** on the floating control.

### Handling "the same photo shows up twice and one opens a website"
- Photo step > *If it appears several times, use* > pick the copy you want.
- In the macro's **Guard**: turn it on, **Block an app** (your browser) and/or type website words (e.g. `ads`). Pick what happens: Back / open an app / open a link / stop.
- Keep **"If that throws me somewhere blocked, go back and try the next copy"** on in the Photo step.
- Or skip clicking entirely: set *When I see it* to **Open link** / **Open app**.

### Conditions (before / after / every Nth cycle / after some time)
Open any step > **Only run this step when…**: from cycle N, until cycle N, every Nth cycle, after/before N seconds of running, after/until another step has run, when a photo is / isn't on screen, when an app is / isn't in front, only X % of the time. All conditions on a step must be true.
Example: step A "tap every 1 s" with *before 60 seconds*, step B "tap every 5 s" with *after 60 seconds*; step C "Stop" with *after 600 seconds*.

### Look human (anti-AFK)
Per step: set **max higher than min** on any wait for a random delay each time. Per macro, **Look human** adds jitter to every delay, tap position and press time, curved swipes and occasional long pauses (Off / Light / Strong presets).

## Honest limits
- Games or apps that block screenshots (secure windows) show up black, so photo matching can't see them. Taps/swipes still work.
- Photo matching is pixel-based: capture the photo on the same phone/screen size you'll run on, crop tightly, and avoid parts that animate or show changing numbers. Tune **Match strictness**; the Activity log prints the best score when nothing matched.
- The website check reads the browser's address bar, which works in Chrome, Samsung Internet, Firefox, Edge, Brave and Opera. For others, block the whole browser app.
- Some apps/games forbid automation in their rules. Randomisation lowers how bot-like clicks look; it doesn't make rule-breaking safe. Use it on your own account and your own risk.

## Extending (how it's built)

```
core/        engine: models, runner, humanizer, vision (OpenCV), guard
actions/     one file per kind of step         <- add new steps here
conditions/  the "only run when…" rules         <- add new conditions here
service/     accessibility service + floating control + capture/pick overlays
data/        macros (JSON files), photo library, import/export
ui/          Jetpack Compose screens (generated from the action field lists)
```

- **New action** (e.g. "type text"): create an `object … : Action` in `actions/`, list its `fields`, write `run()`, add one line to `Actions` in `core/Registry.kt`. The editor form appears automatically. `actions/FlowActions.kt` has tiny examples.
- **New condition:** add one `Cond(...)` line in `conditions/Conditions.kt`.
- **Macros are plain JSON** (Home > ⋯ > Save to file / Copy to share, or Edit as JSON). Shared packs include their photos. Unknown fields are ignored, so older macros keep working when you add features.
- The engine only talks to the phone through the `Device` interface (`core/Device.kt`), so the Android-specific part is one class (`service/ClickerService.kt`).
